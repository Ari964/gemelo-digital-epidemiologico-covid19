import streamlit as st
import json
import os
from auth_helper import render_auth_sidebar, get_api_base_url

st.set_page_config(
    page_title="Data Science Workspace | Gemelo Digital Kenia",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded"
)

render_auth_sidebar()

st.title("🔬 Workspace de Ciencia de Datos - Gemelo Digital Epidemiológico")
st.caption("Metodología CRISP-DM (Fases 1 a 6) | Preparación Pandémica y Modelado Espacio-Temporal para los 47 Condados de Kenia")

st.markdown("""
---
### Metodología CRISP-DM Aplicada a Modelado Epidemiológico

Este entorno de experimentación científica e ingeniería de datos permite auditar, calibrar, evaluar y monitorear los modelos epidemiológicos garantizando separación estricta entre experimentación y despliegue operativo en el Gemelo Digital.

| Fase CRISP-DM | Módulo del Workspace | Objetivo Científico y Operativo |
| :--- | :--- | :--- |
| **Fase 1** | **Comprensión del Negocio** | Definición de objetivos epidemiológicos, NPIs, formulación de H1, DALYs e ICER |
| **Fase 2** | **Comprensión de los Datos** | EDA de 47 condados, censo KNBS 2019, quintiles KDHS 2022, camas UCI KMFL verificadas |
| **Fase 3** | **Preparación de los Datos** | Pipeline ETL trazable, control de calidad, matrices de adyacencia y movilidad estimada (gravitacional) |
| **Fase 4** | **Modelado** | Calibración SciPy (L-BFGS-B), simulación experimental SEIR + ABM y Sensibilidad Global de Sobol (SALib) |
| **Fase 5** | **Evaluación y Aprobación** | Contraste empírico de H1 (Wilcoxon, MAPE, RMSE, R²), evidencia reproducible y Aprobación Técnica |
| **Fase 6** | **Despliegue y Monitoreo** | Despliegue de modelo activo (Singleton), monitoreo on-demand de drift (PSI, KS) y enlace al frontend React |

---
""")

col1, col2, col3, col4 = st.columns(4)
col1.metric("Jurisdicción", "Kenia (47 Condados)")
col2.metric("Población Total (KNBS 2019)", "47,564,296 hab.")
col3.metric("Hipótesis H1", "ΔMAPE ≥ 15.0 pp (p < 0.05)")
col4.metric("Backend de Producción", "FastAPI :8000 (/api/v1)")

st.info("👈 Utiliza el menú lateral para navegar secuencialmente a través de las 6 Fases de CRISP-DM.")
