import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Calendar, 
  AlertTriangle, 
  CheckCircle, 
  Info, 
  Layers, 
  ArrowRight,
  Database,
  Sliders,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import { ApiClient } from '../services/apiClient';
import { HistoricalCutoffsDTO, WeeklyPredictionResponseDTO } from '../types/apiContract';

interface WeeklyForecastingViewProps {
  darkMode: boolean;
}

export const WeeklyForecastingView: React.FC<WeeklyForecastingViewProps> = ({ darkMode }) => {
  const [cutoffsData, setCutoffsData] = useState<HistoricalCutoffsDTO | null>(null);
  const [selectedCutoff, setSelectedCutoff] = useState<string>('2024-07-28');
  const [prediction, setPrediction] = useState<WeeklyPredictionResponseDTO | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Cargar lista dinámica de cortes históricos disponibles
  useEffect(() => {
    loadCutoffs();
  }, []);

  const loadCutoffs = async () => {
    try {
      const data = await ApiClient.getHistoricalCutoffs();
      setCutoffsData(data);
      if (data.available_cutoffs.length > 0) {
        // Seleccionar 2024-07-28 por defecto o el primer corte
        const exists = data.available_cutoffs.some(c => c.date === '2024-07-28');
        const defaultDate = exists ? '2024-07-28' : data.available_cutoffs[0].date;
        setSelectedCutoff(defaultDate);
        executePrediction(defaultDate);
      }
    } catch (err: any) {
      setError('Error al cargar cortes históricos: ' + (err.message || 'Error de conexión'));
    }
  };

  const executePrediction = async (cutoffDate: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await ApiClient.getWeeklyPrediction(cutoffDate, 0);
      setPrediction(res);
    } catch (err: any) {
      setError('Error al calcular predicción: ' + (err.message || 'Error del servidor'));
    } finally {
      setLoading(false);
    }
  };

  const handleSelectCutoff = (date: string) => {
    setSelectedCutoff(date);
    executePrediction(date);
  };

  return (
    <div className="space-y-6">
      {/* Encabezado y Avisos de Alcance */}
      <div className={`p-6 rounded-2xl border ${darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'} shadow-sm`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 text-xs font-semibold rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                CRISP-DM Fase 5 & 6
              </span>
              <span className="px-2.5 py-0.5 text-xs font-semibold rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Ámbito: Nacional (Kenia, country_code=0)
              </span>
              <span className="px-2.5 py-0.5 text-xs font-semibold rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">
                Histórico: 2020 a Agosto 2024
              </span>
            </div>
            <h2 className="text-xl font-bold tracking-tight">
              Vigilancia Epidemiológica Semanal & Exploración de Sensibilidad
            </h2>
            <p className={`text-sm mt-1 ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Predicción semanal verificada mediante persistencia ingenua (modelo campeón) con separación estricta entre pronóstico estadístico y análisis de sensibilidad.
            </p>
          </div>

          <button
            onClick={() => executePrediction(selectedCutoff)}
            disabled={loading}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition cursor-pointer ${
              darkMode ? 'bg-blue-600 hover:bg-blue-500 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
          >
            <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
            Actualizar Predicción
          </button>
        </div>

        {/* Banner de Verificación de Integridad Temporal */}
        <div className="mt-4 p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-start gap-3">
          <ShieldCheck size={20} className="text-blue-400 shrink-0 mt-0.5" />
          <div className="text-xs">
            <span className="font-semibold text-blue-300">Regla de Frecuencia Semanal y Verificación de Retardo:</span>
            <p className={`mt-0.5 ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
              Cada domingo de corte $t_0$ provee <code className="px-1 py-0.5 rounded bg-blue-900/30 text-blue-300 font-mono">weekly_lag_1</code> (casos positivos reportados durante esa semana). El horizonte de pronóstico es estrictamente la semana posterior $t+1 = t_0 + 7\text{ días}$. No existe desfase temporal artificial ni datos futuros filtrados.
            </p>
          </div>
        </div>
      </div>

      {/* Selector Dinámico de Cortes Históricos */}
      <div className={`p-6 rounded-2xl border ${darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'} shadow-sm`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Calendar size={18} className="text-blue-400" />
            <h3 className="text-base font-semibold">Seleccionar Fecha de Corte Histórica (Domingo de Reporte OMS)</h3>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {cutoffsData ? `${cutoffsData.count} cortes disponibles en base` : 'Cargando cortes...'}
          </span>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center gap-2">
            <AlertTriangle size={16} />
            {error}
          </div>
        )}

        {/* Botones de Selección Rápida de Fechas */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 mb-4">
          {cutoffsData?.available_cutoffs.slice(0, 12).map((item) => {
            const isSelected = selectedCutoff === item.date;
            const isReferenceCase = item.date === '2024-07-28';
            return (
              <button
                key={item.date}
                onClick={() => handleSelectCutoff(item.date)}
                className={`p-2.5 rounded-xl text-left border transition cursor-pointer relative ${
                  isSelected
                    ? 'bg-blue-600/20 border-blue-500 text-blue-300 font-bold shadow-md shadow-blue-500/10'
                    : darkMode
                    ? 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800 text-slate-300'
                    : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700'
                }`}
              >
                {isReferenceCase && (
                  <span className="absolute -top-2 -right-1 px-1.5 py-0.2 text-[9px] font-bold rounded bg-amber-500 text-slate-950 shadow">
                    Ref 28-Jul
                  </span>
                )}
                <div className="text-xs font-mono">{item.date}</div>
                <div className="text-[11px] text-slate-400 mt-1">
                  Obs: <span className="font-semibold text-slate-200">{item.new_cases_reported}</span> casos
                </div>
              </button>
            );
          })}
        </div>

        {/* Input libre para ingresar cualquier fecha de corte */}
        <div className="flex flex-col sm:flex-row items-center gap-3 pt-2 border-t border-slate-800/40">
          <label className="text-xs text-slate-400 whitespace-nowrap">
            O ingrese corte manual (YYYY-MM-DD):
          </label>
          <input
            type="date"
            value={selectedCutoff}
            onChange={(e) => setSelectedCutoff(e.target.value)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-mono ${
              darkMode ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'
            }`}
          />
          <button
            onClick={() => executePrediction(selectedCutoff)}
            className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer"
          >
            Evaluar Corte
          </button>
        </div>
      </div>

      {/* RESULTADO: 2 COLUMNAS (PREDICCIÓN PRINCIPAL vs SENSIBILIDAD HIPOTÉTICA) */}
      {prediction && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* PANEL 1: PREDICCIÓN PRINCIPAL (PERSISTENCIA INGENUA - CAMPEÓN) */}
          <div className={`p-6 rounded-2xl border ${darkMode ? 'bg-slate-900/90 border-blue-500/40' : 'bg-white border-blue-400'} shadow-lg shadow-blue-500/5`}>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/60">
              <div className="flex items-center gap-2">
                <CheckCircle size={20} className="text-emerald-400" />
                <h3 className="text-base font-bold text-emerald-400">
                  Predicción Principal (Modelo Seleccionado)
                </h3>
              </div>
              <span className="px-2 py-0.5 text-xs font-bold rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Campeón CV & Diebold-Mariano
              </span>
            </div>

            <div className="mt-4 space-y-4">
              <div>
                <span className="text-xs text-slate-400">Modelo en Producción:</span>
                <div className="text-sm font-mono font-semibold text-slate-200">
                  {prediction.primary_model_name}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 p-4 rounded-xl bg-slate-800/50 border border-slate-700/50">
                <div>
                  <div className="text-[11px] text-slate-400">Fecha de Corte ($t_0$):</div>
                  <div className="text-sm font-mono font-bold text-slate-200">{prediction.cutoff_date}</div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">Semana Pronosticada ($t+1$):</div>
                  <div className="text-sm font-mono font-bold text-blue-400">{prediction.target_week}</div>
                </div>
              </div>

              {/* Gran Tarjeta de Predicción */}
              <div className="p-5 rounded-xl bg-gradient-to-br from-blue-900/30 via-slate-800/50 to-slate-900/80 border border-blue-500/30 text-center">
                <div className="text-xs uppercase tracking-wider text-slate-400 font-semibold">
                  Pronóstico de Casos Semanales $(\hat{y}_{t+1})$
                </div>
                <div className="text-4xl font-extrabold font-mono text-white my-2">
                  {prediction.primary_forecast_cases.toFixed(1)}{' '}
                  <span className="text-sm font-normal text-slate-400">casos</span>
                </div>
                <div className="text-xs text-slate-400">
                  Basado en: <code className="text-blue-300 font-mono">weekly_lag_1 = {prediction.validation_details.weekly_lag_1_used}</code> casos en la semana de corte
                </div>
              </div>

              {/* Comparación con el valor observado real */}
              <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/60 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-slate-400">Valor Realmente Observado en {prediction.target_week}:</div>
                  <div className="text-lg font-mono font-bold text-white">
                    {prediction.target_observed_actual !== null 
                      ? `${prediction.target_observed_actual} casos` 
                      : 'No registrado / Futuro'}
                  </div>
                </div>
                {prediction.forecast_error_mae !== null && (
                  <div className="text-right">
                    <div className="text-[11px] text-slate-400">Error Absoluto (MAE):</div>
                    <div className="text-base font-mono font-bold text-emerald-400">
                      {prediction.forecast_error_mae.toFixed(1)} casos
                    </div>
                  </div>
                )}
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                {prediction.primary_forecast_source}
              </p>
            </div>
          </div>

          {/* PANEL 2: EXPLORACIÓN HIPOTÉTICA DE SENSIBILIDAD (RANDOM FOREST) */}
          <div className={`p-6 rounded-2xl border ${darkMode ? 'bg-slate-900/90 border-amber-500/40' : 'bg-white border-amber-400'} shadow-lg shadow-amber-500/5`}>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/60">
              <div className="flex items-center gap-2">
                <Sliders size={20} className="text-amber-400" />
                <h3 className="text-base font-bold text-amber-400">
                  Exploración Hipotética de Sensibilidad
                </h3>
              </div>
              <span className="px-2 py-0.5 text-xs font-bold rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Random Forest v1.0 (No causal)
              </span>
            </div>

            <div className="mt-4 space-y-4">
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs">
                <span className="font-semibold block mb-1">Advertencia Epistemológica:</span>
                Esta sección es únicamente exploratoria. Los cambios ante variaciones de variables de control no representan efectos causales comprobados de políticas públicas.
              </div>

              {/* Gran Tarjeta de Predicción RF */}
              <div className="p-5 rounded-xl bg-gradient-to-br from-amber-950/20 via-slate-800/50 to-slate-900/80 border border-amber-500/30 text-center">
                <div className="text-xs uppercase tracking-wider text-slate-400 font-semibold">
                  Predicción del Modelo Multivariado $(\text{RF})$
                </div>
                <div className="text-4xl font-extrabold font-mono text-amber-300 my-2">
                  {prediction.hypothetical_rf_prediction !== null
                    ? prediction.hypothetical_rf_prediction.toFixed(2)
                    : 'N/A'}{' '}
                  <span className="text-sm font-normal text-slate-400">casos</span>
                </div>
                <div className="text-xs text-slate-400">
                  Sobrepredice significativamente en periodos de baja incidencia reportada.
                </div>
              </div>

              {/* Imputaciones Críticas Post-2022 */}
              <div className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/60 space-y-2">
                <div className="text-xs font-semibold text-slate-300">
                  Valores de Entrada Utilizados (Post-2022 Imputados):
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">stringency_index:</span>
                    <span className="text-amber-400 font-bold">
                      {prediction.validation_details.imputed_stringency_index ?? '22.77'} (imputado)
                    </span>
                  </div>
                  <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">reproduction_rate:</span>
                    <span className="text-amber-400 font-bold">
                      {prediction.validation_details.imputed_reproduction_rate ?? '0.54'} (imputado)
                    </span>
                  </div>
                </div>
              </div>

              {/* Explicación de la diferencia */}
              <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50 text-xs text-slate-400 leading-relaxed">
                <span className="text-slate-300 font-semibold block mb-1">Causa de la discrepancia:</span>
                {prediction.sensitivity_disclaimer}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CASO DE REFERENCIA OBLIGATORIO: 2024-07-28 & 2024-07-21 */}
      <div className={`p-6 rounded-2xl border ${darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'} shadow-sm`}>
        <div className="flex items-center gap-2 mb-3">
          <Info size={18} className="text-blue-400" />
          <h3 className="text-base font-bold">
            Casos de Referencia Docente: Alineación Temporal y Evaluación Empírica
          </h3>
        </div>

        <p className={`text-xs mb-4 leading-relaxed ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
          Bajo la convención temporal canónica unificada ($t_0 \to t_1 = t_0 + 7\text{ días}$), la persistencia utiliza los casos reales de $t_0$ para pronosticar $t_1$. En la fase endémica plana de baja transmisión, la persistencia simple es empíricamente superior al Random Forest:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Tarjeta Caso 2024-07-28 */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-blue-400">Corte 2024-07-28 (Cierre endémico plano)</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">Persistencia Óptima</span>
            </div>
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div className="p-2 rounded bg-slate-900/50">
                <span className="text-[10px] text-slate-400 block">Corte $t_0$</span>
                <span className="font-bold text-white">0 casos</span>
                <span className="text-[9px] text-slate-500 block">2024-07-28</span>
              </div>
              <div className="p-2 rounded bg-blue-950/40 border border-blue-500/30">
                <span className="text-[10px] text-blue-300 block">Naive $(\hat{y})$</span>
                <span className="font-bold text-white">0.0</span>
                <span className="text-[9px] text-emerald-400 block">Error: 0.0</span>
              </div>
              <div className="p-2 rounded bg-amber-950/40 border border-amber-500/30">
                <span className="text-[10px] text-amber-300 block">RF $(\hat{y})$</span>
                <span className="font-bold text-amber-400">70.76</span>
                <span className="text-[9px] text-red-400 block">Error: 70.76</span>
              </div>
              <div className="p-2 rounded bg-emerald-950/40 border border-emerald-500/30">
                <span className="text-[10px] text-emerald-300 block">Real $t+1$</span>
                <span className="font-bold text-emerald-300">0 casos</span>
                <span className="text-[9px] text-slate-500 block">2024-08-04</span>
              </div>
            </div>
          </div>

          {/* Tarjeta Caso 2024-07-21 */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-400">Corte 2024-07-21 (Corte con 1 caso reportado)</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-mono">Transición</span>
            </div>
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div className="p-2 rounded bg-slate-900/50">
                <span className="text-[10px] text-slate-400 block">Corte $t_0$</span>
                <span className="font-bold text-white">1 caso</span>
                <span className="text-[9px] text-slate-500 block">2024-07-21</span>
              </div>
              <div className="p-2 rounded bg-blue-950/40 border border-blue-500/30">
                <span className="text-[10px] text-blue-300 block">Naive $(\hat{y})$</span>
                <span className="font-bold text-white">1.0</span>
                <span className="text-[9px] text-emerald-400 block">Error: 1.0</span>
              </div>
              <div className="p-2 rounded bg-amber-950/40 border border-amber-500/30">
                <span className="text-[10px] text-amber-300 block">RF $(\hat{y})$</span>
                <span className="font-bold text-amber-400">70.76</span>
                <span className="text-[9px] text-red-400 block">Error: 70.76</span>
              </div>
              <div className="p-2 rounded bg-emerald-950/40 border border-emerald-500/30">
                <span className="text-[10px] text-emerald-300 block">Real $t+1$</span>
                <span className="font-bold text-emerald-300">0 casos</span>
                <span className="text-[9px] text-slate-500 block">2024-07-28</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

