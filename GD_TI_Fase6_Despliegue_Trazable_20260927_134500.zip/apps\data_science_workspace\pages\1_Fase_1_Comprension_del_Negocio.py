import streamlit as st

st.set_page_config(page_title="Fase 1: Comprensión del Negocio | CRISP-DM", page_icon="📋", layout="wide")

st.title("📋 Fase 1 (CRISP-DM) - Comprensión del Negocio Epidemiológico")
st.caption("Objetivos Estratégicos, Formulación de Hipótesis H1, Métricas de Salud Económica y Marco de Equidad")

tab1, tab2, tab3, tab4 = st.tabs([
    "🎯 Objetivos y Contexto",
    "🔬 Hipótesis Científica H1",
    "💰 DALYs e ICER",
    "⚖️ Equidad y Paridad Demográfica"
])

with tab1:
    st.subheader("Contexto Epidemiológico de Kenia")
    st.markdown("""
    Kenia presenta una geografía epidemiológica altamente heterogénea distribuida en **47 condados constitucionales**:
    - **Epicentros Urbanos de Alta Densidad**: Nairobi (4.4M hab.), Mombasa (1.2M hab.), Kisumu, Nakuru.
    - **Condados Pastorales Extensos y Remotos**: Turkana, Marsabit, Wajir, Mandera, Garissa.
    - **Corredores Viales Críticos**: La autopista A104 (Mombasa - Nairobi - Nakuru - Eldoret - Malaba) que canaliza la mayor parte de la movilidad interregional de bienes y personas.
    
    #### Objetivos del Gemelo Digital:
    1. Predecir con precisión la dinámica espacio-temporal de brotes epidémicos inter-condado.
    2. Simular intervenciones no farmacéuticas (NPIs: confinamientos focalizados, cierre de escuelas, restricciones de movilidad).
    3. Evaluar estrategias de distribución de vacunas asegurando la equidad socioeconómica.
    4. Proyectar la saturación de camas de Unidades de Cuidados Intensivos (UCI).
    """)

with tab2:
    st.subheader("Formulación Formal de la Hipótesis Principal H1")
    st.markdown(r"""
    > **Hipótesis H1:**
    > *"El Gemelo Digital Epidemiológico Híbrido (SEIR Espacial Metapoblacional + ABM Intra-Homicilio) reduce el error predictivo porcentual absoluto medio (MAPE) de nuevos casos diarios en al menos 15 puntos porcentuales respecto al modelo SEIR clásico agregado, con significancia estadística formal."*
    
    #### Criterio Matemático de Validación:
    $$\Delta \text{MAPE}_{pp} = \text{MAPE}_{\text{SEIR}} - \text{MAPE}_{\text{Twin}} \ge 15.0\text{ puntos porcentuales}$$
    $$\text{Test de Rangos con Signo de Wilcoxon Pareado: } p < 0.05$$
    
    #### Compromiso Metodológico Irrestricto:
    - **Bloqueo por Datos Sintéticos**: Si se utiliza movilidad generada por modelos sintéticos (gravitacionales), la aprobación de H1 queda **automáticamente bloqueada** con el cartel:
    `"DATOS SINTÉTICOS – NO VÁLIDOS PARA CONCLUSIONES CIENTÍFICAS"`.
    - H1 solo puede ser aprobada sobre matrices empíricas reales (Meta Movement Range + Vigilancia Epidemiológica).
    """)

with tab3:
    st.subheader("Métricas de Salud Económica")
    st.markdown(r"""
    #### Años de Vida Ajustados por Discapacidad (DALYs)
    $$\text{DALY} = \text{YLL} + \text{YLD}$$
    - **YLL (Years of Life Lost)**: $\sum (\text{Defunciones}_a \times L_a)$, donde $L_a$ es la esperanza de vida estándar residual (OMS ~12.5 años promedio para la cohorte de defunciones en Kenia).
    - **YLD (Years Lived with Disability)**: $\sum (\text{Casos}_s \times \text{Duración}_s \times \text{Disability Weight}_s)$.
      - Leve: Peso 0.051 (7 días)
      - Severo: Peso 0.133 (14 días)
      - Crítico (UCI): Peso 0.655 (21 días)
      
    #### Razón de Costo-Efectividad Incremental (ICER)
    $$\text{ICER} = \frac{\text{Costo}_{\text{Intervención}} - \text{Costo}_{\text{Base}}}{\text{DALYs Salvados}} \quad [\text{USD / DALY}]$$
    - **Umbrales OMS para Kenia (PIB per cápita ~ $2,100 USD)**:
      - $\text{ICER} < \$2,100\text{ USD}$: Muy costo-efectivo (< 1x PIB per cápita).
      - $\$2,100 \le \text{ICER} \le \$6,300\text{ USD}$: Costo-efectivo (< 3x PIB per cápita).
      - $\text{ICER} > \$6,300\text{ USD}$: No costo-efectivo.
      - Conversión oficial a chelines kenianos: $1\text{ USD} = 135.0\text{ KES}$.
    """)

with tab4:
    st.subheader("Marco de Equidad y Paridad Demográfica (KDHS 2022)")
    st.markdown(r"""
    Se estratifica la población según los **5 quintiles de riqueza del censo y DHS** (Q1 = Más pobre/vulnerable, Q5 = Más acomodado).
    
    #### Demographic Parity Ratio (DPR)
    $$\text{DPR} = \frac{v_{Q1} / p_{Q1}}{v_{Q5} / p_{Q5}}$$
    donde $v_{Qi}$ es la cobertura vacunal en el quintil $i$, y $p_{Qi}$ es la proporción poblacional.
    
    - **Regla del 80% (Paridad Aceptable)**: $0.80 \le \text{DPR} \le 1.20$.
    - $\text{DPR} < 0.80$: Desventaja adversa para el quintil más desfavorecido.
    - $\text{DPR} > 1.20$: Política de acción afirmativa pro-equidad.
    """)
