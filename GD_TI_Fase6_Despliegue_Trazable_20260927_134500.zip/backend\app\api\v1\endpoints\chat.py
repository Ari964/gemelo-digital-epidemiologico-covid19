import os
from typing import List, Dict, Any, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from backend.app.core.config import settings
from backend.app.models.user import UserDB
from backend.app.api.deps import get_current_user

router = APIRouter()

class ChatMessage(BaseModel):
    role: str  # user, assistant, system
    content: str

class ChatRequest(BaseModel):
    message: str
    conversation_history: Optional[List[ChatMessage]] = None
    simulation_context: Optional[Dict[str, Any]] = None

class ChatResponse(BaseModel):
    reply: str
    model: str
    sources_cited: List[str]

@router.post("", response_model=ChatResponse)
def copilot_chat(
    req: ChatRequest,
    current_user: UserDB = Depends(get_current_user)
):
    api_key = settings.GEMINI_API_KEY or os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Servicio de IA Copilot Epidemiológico no configurado. La variable GEMINI_API_KEY no está establecida en el servidor. Por rigor científico, no se generan respuestas heurísticas simuladas."
        )

    try:
        from google import genai
        client = genai.Client(api_key=api_key)

        # Contexto del sistema especializado en epidemiología de Kenia
        system_instruction = (
            "Eres el Copiloto Epidemiológico de Inteligencia Artificial para el Gemelo Digital "
            "Poblacional de Kenia (47 condados). Tu rol es asesorar a epidemiólogos, ministros de salud "
            "y analistas en la interpretación de simulaciones SEIR + ABM, métricas de equidad (DPR), "
            "DALYs, ICER y evaluación de NPIs. Cita fuentes oficiales como KNBS 2019, KDHS 2022 y KMFL."
        )

        prompt_context = ""
        if req.simulation_context:
            prompt_context = f"\nContexto de simulación actual:\n{req.simulation_context}\n"

        full_prompt = f"{system_instruction}\n{prompt_context}\nUsuario ({current_user.name}): {req.message}"

        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=full_prompt
        )

        return {
            "reply": response.text,
            "model": "gemini-2.5-flash",
            "sources_cited": ["KNBS Census 2019", "KDHS 2022", "KMFL 2021", "MOH Kenya Guidelines"]
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Error en la comunicación con el servicio de IA de Gemini: {str(e)}"
        )
