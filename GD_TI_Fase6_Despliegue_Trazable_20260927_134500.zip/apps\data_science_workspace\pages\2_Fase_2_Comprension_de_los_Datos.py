import streamlit as st
import json
import os
import pandas as pd

st.set_page_config(page_title="Fase 2: Comprensión de los Datos | CRISP-DM", page_icon="📊", layout="wide")

st.title("📊 Fase 2 (CRISP-DM) - Exploración y Comprensión de los Datos")
st.caption("Auditoría de las Fuentes Oficiales: Censo KNBS 2019, Encuesta KDHS 2022 y Camas UCI KMFL")

# Cargar datos verificados
json_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../backend/app/data/kenya_47_counties_verified.json"))

if not os.path.exists(json_path):
    st.error(f"Archivo de condados verificados no encontrado en {json_path}")
    st.stop()

with open(json_path, "r", encoding="utf-8") as f:
    counties_data = json.load(f)

# Convertir a DataFrame
df = pd.DataFrame(counties_data)
df["density_per_sq_km"] = (df["population_2019"] / df["area_sq_km"]).round(1)

# Extraer quintiles a columnas separadas
df["q1_pct"] = df["poverty_quintiles"].apply(lambda x: x.get("q1", 0.2))
df["q5_pct"] = df["poverty_quintiles"].apply(lambda x: x.get("q5", 0.2))

col1, col2, col3, col4 = st.columns(4)
col1.metric("Condados Auditados", f"{len(df)} / 47")
col2.metric("Población Nacional Total", f"{df['population_2019'].sum():,} hab.")
verified_icu_count = df['icu_beds_verified'].notna().sum()
col3.metric("Condados con UCI Verificada", f"{verified_icu_count} / 47")
null_icu_count = df['icu_beds_verified'].isna().sum()
col4.metric("Camas UCI No Verificadas", f"{null_icu_count} (Reportadas NULL)")

st.markdown("""
> **Auditoría de Integridad Científica**: Siguiendo el compromiso irrestricto de no inventar datos,
> los condados sin reporte verificado en el censo hospitalario KMFL/MOH 2021 se mantienen estrictamente
> como `null` en lugar de imputar cifras artificiales.
""")

tab1, tab2, tab3 = st.tabs(["📋 Tabla de los 47 Condados", "🏥 Auditoría de Camas UCI (KMFL)", "🚗 Fuentes de Movilidad"])

with tab1:
    st.subheader("Datos Oficiales KNBS 2019 y KDHS 2022")
    display_df = df[[
        "code", "name", "capital", "population_2019", "area_sq_km",
        "density_per_sq_km", "q1_pct", "q5_pct", "icu_beds_verified"
    ]].copy()
    display_df.columns = [
        "Código", "Condado", "Capital", "Población (2019)", "Área (km²)",
        "Densidad (hab/km²)", "Quintil Q1 (Pobreza)", "Quintil Q5 (Riqueza)", "Camas UCI Verificadas"
    ]
    st.dataframe(display_df, use_container_width=True, height=400)

with tab2:
    st.subheader("Distribución Oficial de Camas de Cuidados Intensivos (KMFL)")
    col_a, col_b = st.columns([2, 1])
    with col_a:
        icu_df = df[df["icu_beds_verified"].notna()].sort_values(by="icu_beds_verified", ascending=False)
        st.bar_chart(data=icu_df, x="name", y="icu_beds_verified", color="#0284C7")
    with col_b:
        st.markdown("**Condados con mayor capacidad UCI oficial:**")
        for _, row in icu_df.head(6).iterrows():
            st.write(f"- **{row['name']}**: {int(row['icu_beds_verified'])} camas ({row['icu_source']})")
        
        st.markdown("---")
        st.markdown(f"**Condados con reporte NULL ({null_icu_count}):**")
        unverified_names = df[df['icu_beds_verified'].isna()]['name'].tolist()
        st.write(", ".join(unverified_names))

with tab3:
    st.subheader("Diferenciación de Fuentes de Movilidad")
    st.markdown("""
    | Fuente | Tipo | Cobertura | Validez Científica H1 |
    | :--- | :--- | :--- | :--- |
    | **Meta Data for Good Movement Range** | **Empírica** | 47 condados (2020-2022) | ✅ **Válida para H1** |
    | **Modelo Gravitacional Sintético** | **Sintética** | Generada por ley de gravedad ($P_i P_j / d^\gamma$) | ❌ **BLOQUEADA PARA H1** |
    """)
    st.warning("⚠️ El uso de datos de movilidad sintética activará la bandera 'DATOS SINTÉTICOS – NO VÁLIDOS PARA CONCLUSIONES CIENTÍFICAS' e impedirá la aprobación de H1.")
