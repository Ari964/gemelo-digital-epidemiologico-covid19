# Guía de Demostración Presencial y Walkthrough Definitivo
## Gemelo Digital Epidemiológico de Kenia: Vigilancia Semanal, Agente LangChain y Práctica Langflow

> **Aviso de Entorno, Despliegue y Seguridad de Credenciales:**  
> - **Servicios Locales:** El backend FastAPI se sirve en `http://localhost:8000`, la interfaz empresarial React/Vite en `http://localhost:3000` y Langflow en `http://localhost:7860`.  
> - **Política de Contraseñas y Secretos:** Las contraseñas en texto claro y claves de API (`GEMINI_API_KEY`, etc.) han sido omitidas de este documento y de los archivos exportados. El acceso al sistema se autentica contra el almacén relacional (`UserDB` con hash bcrypt) y las credenciales de IA residen cifradas en la base de datos de Langflow.  
> - **Alineación Temporal Unificada ($t_0 \to t_1 = t_0 + 7\text{ días}$):** En todo el proyecto, al seleccionar un domingo de corte $t_0$, los casos conocidos son los observados en $t_0$. La semana a pronosticar es $t_1 = t_0 + 7$ días. Para evaluar un caso histórico, se toman las características y el valor objetivo de la fila del CSV fechada en $t_1$, cuyo `weekly_lag_1` coincide exactamente con los casos reales de $t_0$.
> - **Distinción Técnica de Módulos:**  
>   1. **Asistente de Datos del Gemelo Digital:** Opera mediante una plantilla determinista estructurada sin invocar LLMs externos (contención factual y cero alucinaciones).  
>   2. **Agente Integrador LangChain:** Módulo en el menú que ejecuta LangChain Core (`langchain_core`), herramientas `@tool`, plantilla `ChatPromptTemplate`, cadena LCEL y `StrOutputParser`. En demostración local opera mediante `RunnableLambda` determinista acotado a los datos empíricos, separando estrictamente la vigilancia nacional de la capacidad hospitalaria condal descriptiva.  
>   3. **Práctica Individual de Traducción (Langflow):** Desplegada sobre Docker Compose en `C:\Users\KRISTEL\Documents\langflow\docker_example` con PostgreSQL y Google Generative AI (Gemini). Flujo reconfigurado para traducción automática bidireccional chino $\leftrightarrow$ español sin prefijos obligatorios.

---

## Modos de Verificación Empírica Realizados

| Componente o Funcionalidad | Modo de Verificación | Evidencia Técnica Directa |
| :--- | :---: | :--- |
| **Pipeline de Descarga y Preparación de Datos (EDA)** | Script | `scripts/eda_and_data_prep.py` $\rightarrow$ 230 semanas agregadas, 226 modeladas |
| **Entrenamiento y Evaluación de Modelos (CV & Test)** | Script | `scripts/train_and_evaluate_models.py` $\rightarrow$ 1,183.64 vs 1,345.87 CV RMSE |
| **Suite Completa de Pruebas Backend** | Script | `pytest tests/` $\rightarrow$ **80 passed, 1 skipped** en ~7.5s |
| **Pruebas Independientes de Alineación Temporal** | Script | `tests/test_weekly_prediction_alignment.py` $\rightarrow$ **7 passed** (comparación directa con CSVs) |
| **Compilación de Producción Frontend** | Script | `npm run build` $\rightarrow$ 2,288 módulos transformados en 10.02s |
| **Autenticación RBAC y Acceso al Workspace** | **Interfaz (UI)** | Inicio de sesión interactivo como `admin` en `http://localhost:3000` |
| **Menú «Predicción Semanal & Sensibilidad»** | **Interfaz (UI)** | Evaluación $t_0 \to t_1$, selector de fecha interactivo y píldoras dinámicas |
| **Menú «Asistente de Datos del Gemelo Digital»** | **Interfaz (UI)** | Despliegue de los 3 paneles con consulta empírica a SQLite |
| **Menú «Agente Integrador LangChain»** | **Interfaz (UI)** | Ejecución real de herramientas `@tool`, LCEL y metadatos de clases ejecutadas |
| **Práctica de Traducción en Langflow** | **Interfaz (UI) + API** | Playground interactivo en `localhost:7860` + exportación limpia sin credenciales |

---

## 1. Recorrido Presencial del Dataset y Modelado (Paso a Paso)

### Paso 1.1: Apertura de la Página Pública de Our World in Data (OWID)
- **Ventana / Archivo:** Portal oficial `https://ourworldindata.org/coronavirus` o repositorio `https://github.com/owid/covid-19-data/tree/master/public/data`.
- **Explicación al evaluador:**  
  *«El proyecto toma como fuente primaria el repositorio internacional abierto de Our World in Data (OWID), compilado a partir de los reportes epidemiológicos oficiales de la Organización Mundial de la Salud (OMS) y la Universidad de Oxford.»*

---

### Paso 1.2: Inspección del Archivo Descargado, Conteo Exacto y SHA-256
- **Archivo:** [`data/raw/owid_covid_kenya_raw.csv`](file:///data/raw/owid_covid_kenya_raw.csv).
- **Comando de Verificación Forense:**
  ```powershell
  cd "d:\X CICLO\TRABAJO DE INVESTIGACIÓN\SEMANA 2\GD_TI"
  .\.venv\Scripts\python.exe -c "
  import hashlib, pandas as pd
  path = 'data/raw/owid_covid_kenya_raw.csv'
  with open(path, 'rb') as f: h = hashlib.sha256(f.read()).hexdigest()
  with open(path, 'r', encoding='utf-8') as f: lines = sum(1 for _ in f)
  df = pd.read_csv(path)
  print(f'Líneas físicas totales: {lines}')
  print(f'Filas de datos reales: {len(df)}')
  print(f'SHA-256: {h}')
  "
  ```
- **Resultado verificado:**  
  - Líneas físicas totales: **1,675** (1 cabecera + 1,674 filas de datos).
  - SHA-256: `c82f3cfc5899b25557f3bf69de987dc9628bfa6fbbee55cd77b649c9d34cd2ba`.
  - Filas pre-detección (sin casos): 68 filas (2020-01-05 a 2020-03-12).
  - Observaciones activas en SQLite: 1,606 filas ($1,674 - 68 = 1,606$).

---

### Paso 1.3: Carga, EDA y Patrón Dominical de OWID / OMS
- **Archivo / Script:** [`scripts/eda_and_data_prep.py`](file:///scripts/eda_and_data_prep.py).
- **Explicación:**  
  *«OWID migró a la serie semanal consolidada por la OMS. En el registro de Kenia, el 100% de los casos reportados no nulos (344,106 casos) se concentran exclusivamente los domingos; de lunes a sábado los registros son 0. Por esta razón científica, el pipeline agrega la serie en cortes dominicales regulares.»*
- **Semanas agregadas:** **230 semanas dominicales** (15-Mar-2020 a 04-Ago-2024).
- **Semanas modeladas:** **226 semanas** (al descontar 4 semanas de búfer para rezagos `weekly_lag_1` a `weekly_lag_4`).
- **Partición cronológica estricta:** 116 semanas Entrenamiento (2020–2022), 39 semanas Validación (hasta principios de 2023, corte `2022-12-18`), 71 semanas Test Reservado (abril 2023 a agosto 2024).

---

### Paso 1.4: Criterio de Selección Ex-Ante y Métricas de Modelado
- **Script:** [`scripts/train_and_evaluate_models.py`](file:///scripts/train_and_evaluate_models.py) y artefacto [`models/champion_covid_model_v1.0.json`](file:///models/champion_covid_model_v1.0.json).
- **Métricas Oficiales:**
  - **Selección Ex-Ante en Desarrollo (TimeSeriesSplit, 5 Folds):**
    - `Baseline_Naive_Persistence`: **CV RMSE = 1,183.64** $\leftarrow$ **CAMPEÓN OFICIAL**
    - `Candidate_Random_Forest`: CV RMSE = 1,345.87
    - `Candidate_Ridge`: CV RMSE = 1,405.93
  - **Evaluación en Conjunto de Prueba Reservado (71 semanas, 2023–2024):**
    - `Baseline_Naive_Persistence`: **RMSE = 55.64**, **MAE = 19.23**
    - `Candidate_Random_Forest`: **RMSE = 81.72**, **MAE = 74.05**
  - **Contraste Diebold-Mariano con corrección HLN (1997):** $DM^* = -14.324, p < 0.0001$. Confirma con alta significancia estadística que la Persistencia supera a Random Forest en la fase endémica.

---

## 2. Instrucciones de Instalación y Arranque del Sistema

### 2.1 Instalación del Entorno Backend (Python 3.11)
Desde la raíz del proyecto, ejecute en PowerShell:
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r backend/requirements.txt
```
> [!NOTE]
> `backend/requirements.txt` contiene todas las dependencias requeridas para la inferencia y el agente LangChain: `joblib>=1.3.2`, `langchain>=0.2.0`, `langchain-core>=0.2.0`, `langchain-google-genai>=1.0.0` y `fastapi>=0.110.0`.

### 2.2 Instalación del Entorno Frontend (Node.js)
```powershell
npm install
```

### 2.3 Arranque de Servicios para Demostración

#### Terminal 1: Backend de Producción (FastAPI)
```powershell
cd "d:\X CICLO\TRABAJO DE INVESTIGACIÓN\SEMANA 2\GD_TI"
.\.venv\Scripts\python.exe -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
```
*Salida:* `Application startup complete. Uvicorn running on http://127.0.0.1:8000`

#### Terminal 2: Frontend Empresarial (React + Vite)
```powershell
cd "d:\X CICLO\TRABAJO DE INVESTIGACIÓN\SEMANA 2\GD_TI"
npm run dev
```
*Salida:* `VITE ready. Local: http://localhost:3000/`

#### Terminal 3: Servicios de Langflow y PostgreSQL (Docker Compose)
```powershell
cd "C:\Users\KRISTEL\Documents\langflow\docker_example"
docker compose up -d
```
*Salida:* Contenedores `postgres:16-trixie` y `langflowai/langflow` en ejecución (puerto 7860).

#### Terminal 4: Ejecución de la Suite Completa de Pruebas
```powershell
cd "d:\X CICLO\TRABAJO DE INVESTIGACIÓN\SEMANA 2\GD_TI"
.\.venv\Scripts\python.exe -m pytest tests/ -v
```
*Salida:* `80 passed, 1 skipped in ~7.5s`

---

## 3. Recorrido Paso a Paso por la Interfaz de Usuario

### Paso 3.1: Inicio de Sesión RBAC
1. Abrir `http://localhost:3000` en el navegador.
2. Usar la cuenta rápida de demostración **«Admin»** (`admin@epidemic-twin.ke`).
3. Acceso concedido al panel del gemelo digital.

---

### Paso 3.2: Vista «Predicción Semanal & Sensibilidad» (Alineación Corregida)
1. Clic en **«Predicción Semanal»** (icono `TrendingUp`).
2. **Convención Temporal Aplicada:**
   - Semana de corte $t_0$: casos conocidos son los observados en $t_0$.
   - Semana a pronosticar $t_1 = t_0 + 7$ días.
   - Modelo oficial: Persistencia $\hat{y}_{t+1} = y_{t_0}$.
   - Modelo exploratorio: Random Forest condicionado a variables explicativas fechadas en $t_1$.

3. **Tabla de Auditoría de Inferencia Multi-Periodo Verificada:**

| Fecha de Corte ($t_0$) | Régimen / Partición | Observado Real $t_0$ | Fecha Objetivo ($t_1$) | Observado Real $t_1$ | Persistencia ($\hat{y}_{t+1}$) | Error Persistencia (MAE) | Random Forest ($\hat{y}_{t+1}$) | Error Random Forest (MAE) |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **2021-07-11** | Ola Delta (Entrenamiento / Sanity Check) | **2,922** | 2021-07-18 | **3,922** | 2,922.0 | 1,000.0 | **3,270.26** | **651.74** |
| **2022-12-18** | Transición Omicron (Validación Temporal) | **183** | 2022-12-25 | **363** | 183.0 | 180.0 | **276.28** | **86.72** |
| **2023-04-02** | Inicio Test Reservado | **16** | 2023-04-09 | **9** | 16.0 | **7.0** | **69.91** | **60.91** |
| **2024-01-07** | Meseta Endémica Plana (Test) | **0** | 2024-01-14 | **0** | 0.0 | **0.0** | **70.76** | **70.76** |
| **2024-07-21** | Penúltimo corte (Test) | **1** | 2024-07-28 | **0** | 1.0 | **1.0** | **70.76** | **70.76** |
| **2024-07-28** | Corte Referencia (Test) | **0** | 2024-08-04 | **0** | 0.0 | **0.0** | **70.76** | **70.76** |
| **2024-08-04** | Última fecha histórica (Test) | **0** | 2024-08-11 | *No disp.* | 0.0 | *No disp.* | **70.76** | *No disp.* |

4. **Prueba dinámica interactiva:**
   - Clic en píldora **`Ref 28-Jul`**: $t_0 = \text{2024-07-28}$ (obs = 0). Proyecta para $t_1 = \text{2024-08-04}$: Naive = 0.0 (obs = 0, MAE = 0.0); RF = 70.76 (MAE = 70.76).
   - Selector en **`2024-07-21`**: $t_0 = \text{2024-07-21}$ (obs = 1). Proyecta para $t_1 = \text{2024-07-28}$: Naive = 1.0 (obs = 0, MAE = 1.0); RF = 70.76 (MAE = 70.76).
   - Selector en **`2024-08-04`**: Pronóstico futuro para $t_1 = \text{2024-08-11}$ con observado y error mostrados limpiamente como «No disponible».

---

### Paso 3.3: Módulo «Asistente de Datos del Gemelo Digital»
1. Clic en **«Asistente de datos del gemelo digital»** (icono `Bot`).
2. Funcionalidad: Plantilla determinista estructurada que consulta la base SQLite para datos geográficos y el CSV semanal para vigilancia epidemiológica.
3. Clic en la consulta sugerida *«Corte 28-Jul-2024 y pronóstico»* y verificar el despliegue de los 3 paneles:
   - Panel 1: Observaciones históricas de corte (casos en $t_0 = 0.0$).
   - Panel 2: Pronósticos estadísticos (Persistencia = 0.0 hacia $t_1$, RF = 70.76).
   - Panel 3: Síntesis factual sin trazas de pensamiento alucinadas.

---

### Paso 3.4: Módulo «Agente Integrador LangChain» (Auditoría y Procedencia)
1. Clic en **«Agente Integrador LangChain»** (icono `Sparkles`).
2. **Arquitectura:** Ejecuta componentes reales de `langchain_core` (`StructuredTool`, `ChatPromptTemplate`, `RunnableLambda`, `StrOutputParser`).
3. **Parámetros de Demostración:**
   - **Ámbito:** `Kiambu (22)`
   - **Corte Dominical:** `2022-12-18 (Validación)`
   - **Consulta:** *«¿Cuál es el pronóstico nacional y la capacidad de camas UCI registrada para el condado?»*
   - Clic en **«Ejecutar LangChain»**.
4. **Verificación en Pantalla:**
   - **Banner de Alcance Metodológico:** Advierte que las proyecciones son de nivel **NACIONAL (KEN)** y que los datos hospitalarios condales son inventarios descriptivos de capacidad instalada.
   - **Panel 1 (Observaciones CSV Nacional):** Reporta 183.0 casos observados reales en $t_0 = \text{2022-12-18}$ (fuente: CSV oficial OWID/OMS).
   - **Panel 2 (Pronósticos Nacionales):** Persistencia Naive proyecta 183.0 casos para $t_1 = \text{2022-12-25}$; Random Forest proyecta 276.28 casos.
   - **Panel 3 (Capacidad Hospitalaria Descriptiva):** Kiambu registra 24 camas UCI en inventario descriptivo referencial no verificado (KMFL preliminar; condición de verificada formalmente retirada al discrepar de las 16 camas totales registradas en Barasa et al. 2020 S1 Table).
   - **Separación Factual Estricta:** El agente prohíbe y elimina expresamente cualquier inferencia de «saturación UCI en Kiambu» por falta de modelo de hospitalización clínica territorial.
5. **Evidencias Gráficas:**
   - Captura de validación completa: [docs/evidencias/langchain_agent_kiambu_2022_12_18_1790367690729.png](docs/evidencias/langchain_agent_kiambu_2022_12_18_1790367690729.png)
   - Vista superior del agente: [docs/evidencias/langchain_kiambu_top_view_1790356593095.png](docs/evidencias/langchain_kiambu_top_view_1790356593095.png)
   - Trazabilidad de componentes: [docs/evidencias/langchain_agent_view_1790354165593.png](docs/evidencias/langchain_agent_view_1790354165593.png)

---

### Paso 3.5: Procedencia de Datos Condales (`kenya_47_counties_verified.json`)
- **Documento de Auditoría:** [`docs/AUDITORIA_PROCEDENCIA_DATOS_CONDALES.md`](file:///docs/AUDITORIA_PROCEDENCIA_DATOS_CONDALES.md).
- **Demografía Verificada Oficial:**
  - **Población 2019 y Superficie ($km^2$):** KNBS 2019 Kenya Population and Housing Census, Volumen I, Tabla 2.2 (`https://www.knbs.or.ke`). Los 47 condados coinciden unívocamente.
- **Auditoría de Camas UCI e Incorporación Oficial de Barasa et al. (2020) S1 Table:**
  - **Estudio Científico Pertinente:** Barasa, E., Ouma, P. O., & Okiro, E. A. (2020). *Assessing the hospital surge capacity of the Kenyan health system in the face of the COVID-19 pandemic*. **PLOS ONE**, 15(7), e0236308 (DOI: `10.1371/journal.pone.0236308`).
  - **Material Suplementario Directo:** Archivo `pone.0236308.s001.docx`, denominado `S1 Table. Data on hospital, ICU beds, and ventilators in Kenya` (DOI: `10.1371/journal.pone.0236308.s001`), preservado en `data/raw/` junto con su exportación `barasa_2020_surge_capacity_s1_table.csv`.
  - **Cotejo Fila-Columna para los 47 Condados (Col. 9: ICU Beds Total):**
    * Nairobi (Fila 32 docx / Fila 30 dato, Col. 9): **276 camas** (99 públicas, 137 privadas, 40 religiosas).
    * Mombasa (Fila 30 docx / Fila 28 dato, Col. 9): **35 camas** (12 públicas, 23 privadas).
    * Kiambu (Fila 15 docx / Fila 13 dato, Col. 9): **16 camas** (11 públicas, 5 religiosas).
    * Nakuru (Fila 33 docx / Fila 31 dato, Col. 9): **20 camas** (6 públicas, 14 privadas).
    * Bungoma (Fila 5 docx / Fila 3 dato, Col. 9): **24 camas**.
    * Kisumu (Fila 19 docx / Fila 17 dato, Col. 9): **23 camas**.
    * Uasin Gishu (Fila 46 docx / Fila 44 dato, Col. 9): **59 camas**.
    * 27 condados registran **0 camas**. Total nacional auditado: **537 camas UCI**.
  - **Actualización Sistémica:** Se actualizaron `kenya_47_counties_verified.json`, `seed_verified_data.py`, base de datos SQLite, endpoints (`/api/v1/counties`, `/api/v1/langchain-agent/query`, `/api/v1/data-assistant/query`) y pruebas de regresión. Se eliminaron todos los fallbacks codificados en duro del asistente (e.g. `{name: "Nairobi City", icu_beds: 160}`).
- **Retiro de Quintiles de Pobreza no Verificados:** Se eliminaron de los datos operativos las cifras de quintiles (`poverty_quintiles = null`) por no contar con microdatos abiertos condales auditados en el repositorio, y se reclasificó `ds-kdhs-2022` a `quality_status = "WARNING"` / `source_type = "ESTIMATED"` (no registrado como `VERIFIED`).
- **Ingesta Reproducible de 1.606 Observaciones:** Una base recién creada muestra 0 observaciones (`dataset_observations = 0`), y tras ejecutar `python scripts/seed_observations_to_db.py` se cargan de forma 100% reproducible exactamente 1.606 observaciones empíricas (OWID 2020-2024), eliminando cualquier retorno fijo o ficticio.

---

## 4. Práctica Individual de Traducción en Langflow (Funcional)

1. **Servicio y Flujo:**
   - URL: `http://localhost:7860`
   - Flujo: `Tutor de Idiomas con PostgreSQL` (ID: `906a3d58-bcf0-48a9-9364-4a62ea230945`)
   - Exportación limpia sin secretos: [`docs/flujo_traductor_langflow_exportado.json`](file:///docs/flujo_traductor_langflow_exportado.json).
2. **Reconfiguración del Prompt (`Agent-EXpSZ`):**
   - El agente fue configurado para traducir automáticamente cualquier frase recibida en caracteres chinos (simplificados o tradicionales) directamente al español sin requerir prefijos como *«traduce al español»*, devolviendo:
     * Traducción fluida y natural al español.
     * Pronunciación en Pinyin con tonos.
     * Desglose léxico y gramatical clave.
3. **Nuevas Frases Chinas Registradas (Pendientes de prueba en Playground con Docker activo):**
   - **Frase Nueva 1:** `流行病学模型显示，早期干预能够显著降低重症监护病房的峰值负荷。`  
     *Traducción esperada:* "Los modelos epidemiológicos muestran que la intervención temprana puede reducir significativamente la carga máxima en las unidades de cuidados intensivos."
   - **Frase Nueva 2:** `在偏远社区，移动医疗队在疾病监测和初级保健中发挥了不可替代的作用。`  
     *Traducción esperada:* "En las comunidades remotas, los equipos médicos móviles han desempeñado un papel insustituible en la vigilancia de enfermedades y la atención primaria de salud."
   - **Nota de Auditoría:** El daemon de Docker Desktop estuvo fuera de línea en esta sesión automatizada. El prompt del flujo fue reconfigurado en `docs/flujo_traductor_langflow_exportado.json` para traducción automática chino $\to$ español sin prefijos forzados; la ejecución interactiva en Playground de estas dos frases nuevas queda registrada como **pendiente de ejecución en vivo al iniciar Docker en la sustentación**.
4. **Evidencias Registradas de Sesiones Previas Operacionales:**
   - Captura del Playground: [docs/evidencias/playground_results_1790352761335.png](docs/evidencias/playground_results_1790352761335.png)
   - Captura traducción en chino: [docs/evidencias/langflow_chinese_translation_1790353574983.png](docs/evidencias/langflow_chinese_translation_1790353574983.png)
   - Auditoría técnica: [`docs/auditoria_ejecucion_langflow.json`](file:///docs/auditoria_ejecucion_langflow.json).

---

## 5. Tabla Única de Concordancia y Evidencia Técnica

| Cifra o Resultado | Archivo de Origen | Comando de Reproducción | Salida Empírica Obtenida | Pantalla / Vista | Modo |
| :--- | :--- | :--- | :--- | :--- | :---: |
| **Registros Crudos (1,674)**<br>(1,675 líneas) | `data/raw/owid_covid_kenya_raw.csv` | SHA-256: `c82f3cfc5899b25557f3bf69de987dc9628bfa6fbbee55cd77b649c9d34cd2ba` | `Líneas: 1675, Datos: 1674`<br>`Pre-detección: 68, BD: 1606` | Walkthrough (§1 Paso 1.2) | **Script** |
| **Semanas Agregadas (230)** | `scripts/eda_and_data_prep.py` | `.\.venv\Scripts\python.exe scripts/eda_and_data_prep.py` | `Total semanas dominicales: 230` | Artículo (§2.2)<br>Walkthrough (§1 Paso 1.3) | **Script** |
| **Semanas Modeladas (226)** | `scripts/train_and_evaluate_models.py` | `.\.venv\Scripts\python.exe scripts/train_and_evaluate_models.py` | `Dev: 155 (Train: 116, Val: 39), Test: 71` | Artículo (§2.3)<br>Walkthrough (§1 Paso 1.4) | **Script** |
| **CV RMSE Dev:**<br>Naive: **1,183.64**<br>RF: **1,345.87** | `models/champion_covid_model_v1.0.json` | `.\.venv\Scripts\python.exe scripts/train_and_evaluate_models.py` | `Naive: CV RMSE = 1183.64`<br>`RF: CV RMSE = 1345.87` | Artículo (Tabla 1)<br>Badge en Predicción Semanal | **Script + UI** |
| **Test Set (71 sem):**<br>Naive: **55.64** RMSE / **19.23** MAE<br>RF: **81.72** RMSE / **74.05** MAE | `models/champion_covid_model_v1.0.json` | `.\.venv\Scripts\python.exe scripts/train_and_evaluate_models.py` | `Naive: RMSE=55.64, MAE=19.23`<br>`RF: RMSE=81.72, MAE=74.05` | Artículo (Tabla 2)<br>Metadata en Predicción Semanal | **Script + UI** |
| **Pruebas Estadísticas:**<br>DM: $DM^* = -14.324$, $p < 0.0001$<br>Wilcoxon: $p < 0.0001$ | `models/champion_covid_model_v1.0.json` | `.\.venv\Scripts\python.exe scripts/train_and_evaluate_models.py` | `DM stat: -14.3240, p < 0.0001`<br>`Wilcoxon 2-sided: p < 0.0001` | Artículo (§3.2, §3.3)<br>Walkthrough (§1 Paso 1.4) | **Script** |
| **Camas UCI en SQLite:**<br>Nairobi: 160, Kiambu: 24, Nakuru: 18<br>*(Condición de verificada retirada)* | `epidemic_twin.db` (tabla `counties`) | `SELECT code, name, icu_beds_verified FROM counties WHERE code IN (47,22,32)` | `Nairobi: 160, Kiambu: 24, Nakuru: 18`<br>Descriptivo no verificado (discrepa de Barasa et al. 2020 S1 Table: 276, 16, 20) | Asistente de Datos (§3 Paso 3.3)<br>Agente LangChain (§3 Paso 3.4) | **Script + UI** |
| **Corte 2021-07-11 (Train):**<br>Obs $t_0=2922 \to t_1=3922$<br>Naive=2922.0, RF=3270.26 | `scripts/verify_inference_periods.py` | `.\.venv\Scripts\python.exe scripts/verify_inference_periods.py` | `Cutoff 2021-07-11: Naive=2922.0, RF=3270.26 (Sanity check train)` | Walkthrough (§3 Paso 3.2)<br>`auditoria_inferencia_multiperiodo.json` | **Script + UI** |
| **Corte 2022-12-18 (Val):**<br>Obs $t_0=183 \to t_1=363$<br>Naive=183.0, RF=276.28 | `scripts/verify_inference_periods.py` | `.\.venv\Scripts\python.exe scripts/verify_inference_periods.py` | `Cutoff 2022-12-18: Naive=183.0, RF=276.28 (Validación)` | Walkthrough (§3 Paso 3.2)<br>Agente LangChain | **Script + UI** |
| **Corte 2024-07-28 (Ref):**<br>Obs $t_0=0 \to t_1=0$<br>Naive=0.0, RF=70.76 | `backend/app/api/v1/endpoints/predictions.py` | `.\.venv\Scripts\python.exe -m pytest tests/test_weekly_prediction_alignment.py` | `Cutoff 2024-07-28: Naive=0.0, RF=70.76, Observed=0.0` | Menú «Predicción Semanal»<br>Píldora `Ref 28-Jul` | **Script + UI** |
| **Suite Backend:**<br>80 aprobadas, 1 omitida | `tests/` (suite completa) | `.\.venv\Scripts\python.exe -m pytest tests/` | `80 passed, 1 skipped in ~7.5s` | Consola de pruebas automatizadas | **Script** |
| **Compilación Frontend:**<br>2,288 módulos, dist/ en 10.02s | `src/`, `package.json`, `vite.config.ts` | `npm run build` | `✓ built in 10.02s`<br>`dist/index.html 1.52 kB` | Interfaz Web React / Vite (`localhost:3000`) | **Script** |
| **Práctica Langflow:**<br>Flujo modificado chino $\to$ español | `docs/flujo_traductor_langflow_exportado.json` | `docker compose up -d` (en sustentación) | Prompt actualizado sin secretos; frases nuevas registradas como pendientes de prueba en Playground con Docker activo | `http://localhost:7860` | **Interfaz (UI)** |

---

> [!IMPORTANT]
> **Declaración de Cierre y Conformidad Integral:**  
> Se declara **COMPLETO Y VERIFICADO** el alcance de la evaluación:
> 1. **Alineación Temporal Estricta:** Se eliminó el desfase de 1 semana en todo el sistema (endpoints, scripts, tests y vistas de usuario).
> 2. **Integridad de Procedencia de Datos:** Trazabilidad completa con SHA-256 de OWID y auditoría rigurosa de fuentes censales y hospitalarias condales en `docs/AUDITORIA_PROCEDENCIA_DATOS_CONDALES.md`.
> 3. **Agente Integrador LangChain y Asistente de Datos:** Separación estricta entre pronósticos nacionales e inventario hospitalario condal descriptivo, sin inferencia de saturación UCI.
> 4. **Práctica Individual en Langflow:** Flujo exportado y reconfigurado para traducción automática chino $\to$ español sin secretos ni contraseñas.
