/**
 * API Contract Types matching FastAPI /api/v1 schemas (CRISP-DM Fases 1-6)
 */

export interface UserDTO {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'epidemiologist' | 'analyst';
  status: 'active' | 'suspended';
  created_at: string;
}

export interface TokenResponseDTO {
  access_token: string;
  refresh_token: string;
  token_type: string;
  user_id: string;
  email: string;
  name: string;
  role: 'admin' | 'epidemiologist' | 'analyst';
}

export interface CountyDTO {
  code: number;
  iso_code: string;
  name: string;
  capital: string;
  population_2019: number;
  area_sq_km: number;
  latitude: number;
  longitude: number;
  poverty_quintiles: {
    q1: number;
    q2: number;
    q3: number;
    q4: number;
    q5: number;
  };
  icu_beds_verified: number | null;
  icu_source: string | null;
  data_quality_flags: string[];
}

export interface SimulationParamsDTO {
  days: number;
  npi_stringency: number;
  vaccine_coverage: number;
  school_closure: boolean;
  border_screening: boolean;
  initial_infected_county: number;
  initial_cases: number;
  use_empirical_mobility: boolean;
  seed: number;
  run_mode?: 'EXPERIMENTAL' | 'OPERATIONAL';
  model_version?: string;
}

export interface SimulationResponseDTO {
  simulation_id: string;
  model_type: string;
  is_synthetic: boolean;
  is_demo?: boolean;
  run_mode?: string;
  model_version?: string;
  is_operational?: boolean;
  warning: string | null;
  execution_time_ms: number;
  parameters_hash: string;
  seed: number;
  national_summary: {
    total_cases: number;
    total_deaths: number;
    peak_infections: number;
    peak_day: number;
    attack_rate: number;
  };
  national_time_series: {
    daily_cases: number[];
    active_infected: number[];
    cumulative_deaths: number[];
  };
  county_results: Array<{
    code: number;
    name: string;
    population: number;
    total_cases: number;
    total_deaths: number;
    peak_infected: number;
    peak_day: number;
    icu_beds_verified: number | null;
    icu_saturated: boolean;
    daily_cases: number[];
  }>;
  household_equity: {
    demographic_parity_ratio: number;
    attack_rate_by_quintile: Record<string, number>;
    equity_assessment: string;
  };
  health_economics: {
    dalys_total: number;
    yll: number;
    yld: number;
    intervention_cost_usd: number;
    intervention_cost_kes: number;
    currency_rates: { USD_KES: number };
  };
}

export interface AuditLogDTO {
  id: string;
  timestamp: string;
  user_id: string;
  user_email: string;
  user_role: string;
  action: string;
  parameters_hash: string;
  seed: number;
  execution_time_ms: number;
  details?: string;
}

export interface ValidationStatusDTO {
  external_validation_2023_2024: {
    period: string;
    status: 'PENDING' | 'AVAILABLE';
    dataset_available: boolean;
    note: string;
    mape: number | null;
    rmse: number | null;
    r2: number | null;
    records_count: number;
  };
  datasets: Array<{
    name: string;
    source: string;
    source_type?: string;
    quality_status?: string;
    is_synthetic: boolean;
    records_count: number;
    coverage_pct: number;
    sha256_hash?: string;
  }>;
  h1_criteria: {
    hypothesis: string;
    condition: string;
    benchmark: string;
  };
  technical_approval_gate: {
    min_coverage_pct: number;
    prohibit_synthetic: boolean;
    min_r2: number;
  };
}

export interface EvaluationResponseDTO {
  id: string;
  candidate_sim_id: string;
  baseline_sim_id: string;
  candidate_model_name: string;
  candidate_model_version: string;
  baseline_model_name: string;
  baseline_model_version: string;
  observed_dataset_id: string;
  observed_dataset_version: string;
  observed_dataset_hash: string | null;
  sources_used: string[];
  period_start: string | null;
  period_end: string | null;
  territory_scope: string;
  aggregation_level: string;
  target_variable: string;
  target_unit: string;
  observations_count: number;
  zero_policy: string;
  exclusions_count: number;
  is_demo: boolean;
  unavailability_reason: string | null;
  mape: number | null;
  rmse: number | null;
  r2: number | null;
  wilcoxon_p_value: number | null;
  wilcoxon_statistic: number | null;
  psi_value: number | null;
  psi_status: string | null;
  ks_statistic: number | null;
  ks_p_value: number | null;
  h1_status: string;
  h1_supported: boolean;
  technical_approval_status: string;
  created_at: string;
}

export interface ActiveModelResponseDTO {
  is_active: boolean;
  model_name?: string;
  model_version?: string;
  artifact_sha256?: string;
  activated_at?: string;
  activated_by?: string;
  candidate_eval_id?: string;
  parameters?: Record<string, any>;
  message?: string;
}

export interface MonitoringStatusDTO {
  active_model_name: string | null;
  active_model_version: string | null;
  is_active: boolean;
  overall_status: 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'PENDING';
  last_evaluated_at: string | null;
  unavailability_reason: string | null;
  psi_value: number | null;
  psi_status: string | null;
  ks_p_value: number | null;
  ks_status: string | null;
}

export interface SobolStatusDTO {
  analysis_id: string;
  status: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'INTERRUPTED';
  progress_pct: number;
  model_engine: string;
  n_samples: number;
  calc_second_order: boolean;
  seed: number;
  sobol_indices: Array<{
    parameter: string;
    S1: number;
    S1_conf: number;
    ST: number;
    ST_conf: number;
  }>;
  second_order_indices?: Array<{
    param1: string;
    param2: string;
    S2: number;
    S2_conf: number;
  }>;
  most_sensitive_parameter?: string;
  error_message?: string;
}

export interface HistoricalCutoffItemDTO {
  date: string;
  new_cases_reported: number;
  new_cases_smoothed: number;
  new_deaths: number;
  target_next_week_cases?: number;
}

export interface HistoricalCutoffsDTO {
  dataset_source: string;
  count: number;
  available_cutoffs: HistoricalCutoffItemDTO[];
  recommended_test_case: {
    cutoff_date: string;
    next_week_observed: number;
    naive_persistence_prediction: number;
    random_forest_prediction: number;
    explanation: string;
  };
}

export interface WeeklyPredictionResponseDTO {
  cutoff_date: string;
  target_week: string;
  geographic_scope: string;
  primary_model_name: string;
  primary_forecast_cases: number;
  primary_forecast_source: string;
  target_observed_actual: number | null;
  forecast_error_mae: number | null;
  hypothetical_rf_prediction: number | null;
  sensitivity_disclaimer: string;
  validation_details: Record<string, any>;
}

export interface DataAssistantResponseDTO {
  query: string;
  database_observations: Record<string, any>;
  model_forecasts: Record<string, any>;
  ai_interpretation: string;
  tools_used: string[];
  sources_consulted: string[];
}
