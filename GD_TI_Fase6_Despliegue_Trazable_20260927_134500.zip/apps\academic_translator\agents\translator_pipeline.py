import os
import json
from typing import Dict, Any, List

class AcademicTranslatorPipeline:
    """
    Pipeline Multi-Agente de Traducción Académica Especializada.
    Integra Gemini vía Google GenAI / LangChain:
    1. Agente Traductor Científico
    2. Agente de Preservación Terminológica (Glosario Epidemiológico)
    3. Agente Revisor por Pares (Peer Review & Refinamiento Académico)
    
    REGLA: Cero respuestas heurísticas simuladas. Si la API falla o no está configurada,
    se propaga el error estructurado.
    """
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY", "")
        self.glossary = self._load_glossary()

    def _load_glossary(self) -> Dict[str, str]:
        glossary_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../utils/epidemiology_glossary.json"))
        if os.path.exists(glossary_path):
            with open(glossary_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}

    def translate_document(
        self,
        text: str,
        filename: str,
        target_lang: str = "es"
    ) -> Dict[str, Any]:
        if not self.api_key:
            raise ValueError(
                "Servicio de Traducción Académica no disponible: GEMINI_API_KEY no configurada. "
                "Por rigor científico, no se generan traducciones heurísticas simuladas."
            )

        try:
            from google import genai
            client = genai.Client(api_key=self.api_key)

            # Preparar términos del glosario relevantes
            glossary_snippet = json.dumps(self.glossary, ensure_ascii=False, indent=2)

            system_prompt = (
                f"Eres un Traductor Académico Senior y Editor Científico de revistas médicas de alto impacto (The Lancet, Nature Medicine). "
                f"Traduce el siguiente manuscrito científico manteniendo la máxima fidelidad conceptual y estilo formal en idioma '{target_lang}'.\n"
                f"REGLA OBLIGATORIA DE PRESERVACIÓN TERMINOLÓGICA: Respeta estrictamente este glosario:\n{glossary_snippet}\n"
                f"Conserva intactas las ecuaciones matemáticas, variables (S, E, I, R, D, beta, gamma, sigma), acrónimos y citas."
            )

            response = client.models.generate_content(
                model='gemini-2.5-flash',
                contents=f"{system_prompt}\n\nDocumento a traducir ({filename}):\n{text}"
            )

            translated_text = response.text

            return {
                "filename": filename,
                "translated_text": translated_text,
                "model_used": "gemini-2.5-flash",
                "glossary_terms_enforced": len(self.glossary),
                "status": "COMPLETED"
            }
        except Exception as e:
            raise RuntimeError(f"Fallo en la llamada a la API de traducción académica: {str(e)}")
