import io
import json
import uuid
import hashlib
from datetime import datetime
from typing import Dict, Any, Optional, List
from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy.orm import Session

from backend.app.db.session import get_db
from backend.app.models.user import UserDB
from backend.app.models.audit import AuditLogDB
from backend.app.models.simulation import SimulationRunDB
from backend.app.models.evaluation import EvaluationRunDB
from backend.app.schemas.report import ExportReportRequest, ExportReportByIdRequest
from backend.app.api.deps import get_current_user

# Export libraries
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

router = APIRouter()


def _build_pdf_story(title: str, user_name: str, user_role: str, is_demo: bool,
                     summary: Dict[str, Any], evaluation: Optional[EvaluationRunDB] = None,
                     county_results: Optional[list] = None) -> list:
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        textColor=colors.HexColor('#0F172A')
    )
    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=13,
        textColor=colors.HexColor('#64748B')
    )
    section_style = ParagraphStyle(
        'SectionHeader',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=15,
        textColor=colors.HexColor('#0284C7'),
        spaceBefore=8,
        spaceAfter=5
    )
    alert_style = ParagraphStyle(
        'DocAlert',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#DC2626')
    )
    disclaimer_style = ParagraphStyle(
        'DocDisclaimer',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=8,
        leading=11,
        textColor=colors.HexColor('#475569')
    )

    story = []
    story.append(Paragraph(title, title_style))
    date_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    story.append(Paragraph(f"Gemelo Digital Epidemiológico de Kenia | Trazabilidad CRISP-DM | Responsable: {user_name} ({user_role}) | {date_str}", subtitle_style))
    story.append(Spacer(1, 6))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#0284C7"), spaceBefore=2, spaceAfter=8))

    if is_demo:
        story.append(Paragraph("AVISO: REPORTE EN MODO DEMOSTRACIÓN / EXPERIMENTAL – ARTEFACTO CON HASH SHA-256", alert_style))
        story.append(Paragraph("Los datos contienen supuestos estimados o sintéticos. La validación externa independiente con microdatos permanece pendiente.", disclaimer_style))
        story.append(Spacer(1, 8))

    if evaluation:
        story.append(Paragraph("Evidencia de Evaluación Experimental Formal (Fase 5 CRISP-DM)", section_style))
        
        coverage_str = f"{evaluation.data_coverage_pct:.1f}%" if evaluation.data_coverage_pct is not None else "N/D"
        mape_cand_str = f"{evaluation.mape_candidate:.2f}%" if evaluation.mape_candidate is not None else "Pendiente"
        mape_base_str = f"{evaluation.mape_baseline:.2f}%" if evaluation.mape_baseline is not None else "Pendiente"
        delta_mape_str = f"{evaluation.delta_mape_pp:.2f} pp" if evaluation.delta_mape_pp is not None else "Pendiente"
        rmse_cand_str = f"{evaluation.rmse_candidate:.2f}" if evaluation.rmse_candidate is not None else "Pendiente"
        r2_cand_str = f"{evaluation.r2_candidate:.4f}" if evaluation.r2_candidate is not None else "Pendiente"
        wilcox_p_str = f"{evaluation.wilcoxon_p_value:.6f}" if evaluation.wilcoxon_p_value is not None else "Pendiente"

        eval_data = [
            ["Parámetro de Reproducibilidad", "Detalle / Valor Persistido"],
            ["ID Evaluación", evaluation.id],
            ["Simulación Candidata", evaluation.candidate_simulation_id],
            ["Simulación Base (Baseline)", evaluation.baseline_simulation_id or "Sin baseline comparativo"],
            ["Dataset Observado", f"{evaluation.observed_dataset_id} (v{evaluation.observed_dataset_version})"],
            ["Procedencia Insumos", evaluation.source_type],
            ["Cobertura Observada", coverage_str],
            ["Periodo Evaluado", f"{evaluation.period_start or 'N/D'} a {evaluation.period_end or 'N/D'}"],
            ["Nivel Territorial", f"{evaluation.aggregation_level} ({evaluation.territory_scope})"],
            ["Variable Objetivo", f"{evaluation.target_variable} ({evaluation.target_unit})"],
            ["Observaciones Usadas (N)", str(evaluation.observations_count)],
            ["Política de Ceros/Faltantes", evaluation.zero_handling_method or "epsilon_smoothed_mape_eps_1.0"],
            ["Solapamiento Calibración", "DETECTADO (No independiente)" if evaluation.overlap_detected else "NINGUNO (Independiente)"],
            ["Elegible para H1", "SÍ" if evaluation.eligible_for_h1 else "NO"],
            ["MAPE Candidato (Twin)", mape_cand_str],
            ["MAPE Base (SEIR Clásico)", mape_base_str],
            ["Delta MAPE (Mejora)", delta_mape_str],
            ["RMSE Candidato", rmse_cand_str],
            ["R² Candidato", r2_cand_str],
            ["Wilcoxon p-value", wilcox_p_str],
            ["Estado Hipótesis H1", evaluation.h1_status],
            ["Conclusión Científica", evaluation.scientific_conclusion or "Pendiente de evaluación formal"]
        ]
        t_eval = Table(eval_data, colWidths=[180, 320])
        t_eval.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#0F172A")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8FAFC")])
        ]))
        story.append(t_eval)
        story.append(Spacer(1, 10))

    if summary:
        story.append(Paragraph("Resumen Epidemiológico Simulado", section_style))
        summary_data = [
            ["Métrica", "Valor"],
            ["Total Casos Acumulados", f"{summary.get('total_cases', 0):,}"],
            ["Total Defunciones", f"{summary.get('total_deaths', 0):,}"],
            ["Pico Máximo de Infecciones", f"{summary.get('peak_infections', 0):,}"],
            ["Día del Pico", f"Día {summary.get('peak_day', 0)}"],
            ["Tasa de Ataque Poblacional", f"{summary.get('attack_rate', 0)*100:.2f}%"]
        ]
        t_summary = Table(summary_data, colWidths=[180, 320])
        t_summary.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#0369A1")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor("#F0F9FF")])
        ]))
        story.append(t_summary)
        story.append(Spacer(1, 10))

    # Pie de página sobre integridad
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#CBD5E1"), spaceBefore=10, spaceAfter=4))
    story.append(Paragraph("Artefacto verificado con hash SHA-256 | Validación externa permanece pendiente de microdatos empíricos 2023-2024.", disclaimer_style))
    return story


@router.post("/export/by-id/pdf")
def export_pdf_by_id(
    req: ExportReportByIdRequest,
    db: Session = Depends(get_db),
    current_user: UserDB = Depends(get_current_user)
):
    """
    Exporta un informe PDF oficial basado estrictamente en registros persistidos en Base de Datos.
    """
    is_demo = True
    summary = {}
    evaluation = None

    if req.evaluation_id:
        evaluation = db.query(EvaluationRunDB).filter(EvaluationRunDB.id == req.evaluation_id).first()
        if not evaluation:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Evaluación con ID '{req.evaluation_id}' no encontrada."
            )
        is_demo = evaluation.is_demo
        sim = db.query(SimulationRunDB).filter(SimulationRunDB.id == evaluation.candidate_simulation_id).first()
        if sim and sim.results_summary_json:
            try:
                summary = json.loads(sim.results_summary_json)
            except Exception:
                summary = {}
    elif req.simulation_id:
        sim = db.query(SimulationRunDB).filter(SimulationRunDB.id == req.simulation_id).first()
        if not sim:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Simulación con ID '{req.simulation_id}' no encontrada."
            )
        is_demo = getattr(sim, "is_demo", True)
        if sim.results_summary_json:
            try:
                summary = json.loads(sim.results_summary_json)
            except Exception:
                summary = {}

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=36,
        leftMargin=36,
        topMargin=36,
        bottomMargin=36
    )

    story = _build_pdf_story(
        title=req.title or "Dossier Epidemiológico Oficial",
        user_name=current_user.name,
        user_role=current_user.role,
        is_demo=is_demo,
        summary=summary,
        evaluation=evaluation
    )
    doc.build(story)
    pdf_bytes = buffer.getvalue()
    buffer.close()

    content_hash = hashlib.sha256(pdf_bytes).hexdigest()

    audit_entry = AuditLogDB(
        id=f"aud-{uuid.uuid4().hex[:12]}",
        user_id=current_user.id,
        user_email=current_user.email,
        user_role=current_user.role,
        action="EXPORT_PDF_BY_ID",
        parameters_hash=content_hash,
        seed=42,
        execution_time_ms=50,
        details=json.dumps({
            "target_simulation_id": req.simulation_id,
            "target_evaluation_id": req.evaluation_id,
            "sha256_hash": content_hash,
            "is_demo": is_demo
        })
    )
    db.add(audit_entry)
    db.commit()

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename=Dossier_Kenia_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.pdf",
            "X-Content-SHA256": content_hash
        }
    )


@router.post("/export/by-id/excel")
def export_excel_by_id(
    req: ExportReportByIdRequest,
    db: Session = Depends(get_db),
    current_user: UserDB = Depends(get_current_user)
):
    """
    Exporta un archivo Excel (.xlsx) oficial a partir de registros persistidos en base de datos.
    """
    evaluation = None
    sim = None
    summary = {}
    county_data = []

    if req.evaluation_id:
        evaluation = db.query(EvaluationRunDB).filter(EvaluationRunDB.id == req.evaluation_id).first()
        if not evaluation:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Evaluación con ID '{req.evaluation_id}' no encontrada."
            )
        sim = db.query(SimulationRunDB).filter(SimulationRunDB.id == evaluation.candidate_simulation_id).first()
    elif req.simulation_id:
        sim = db.query(SimulationRunDB).filter(SimulationRunDB.id == req.simulation_id).first()
        if not sim:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Simulación con ID '{req.simulation_id}' no encontrada."
            )

    if sim:
        if sim.results_summary_json:
            try:
                summary = json.loads(sim.results_summary_json)
            except Exception:
                summary = {}
        county_res_attr = getattr(sim, "county_results_json", None)
        if county_res_attr:
            try:
                county_data = json.loads(county_res_attr)
            except Exception:
                county_data = []

    wb = openpyxl.Workbook()
    header_font = Font(name="Arial", size=10, bold=True, color="FFFFFF")
    cell_font = Font(name="Arial", size=9)

    # Sheet 1: Resumen Simulación
    ws_summary = wb.active
    ws_summary.title = "Resumen Simulación"
    ws_summary.append(["Indicador", "Valor"])
    for cell in ws_summary[1]:
        cell.fill = PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")
        cell.font = header_font

    if sim:
        ws_summary.append(["ID Simulación", sim.id])
        ws_summary.append(["Modelo", sim.model_version or "N/A"])
        ws_summary.append(["Modo de Ejecución", getattr(sim, "run_mode", "EXPERIMENTAL")])
        ws_summary.append(["Fecha Inicio Simulación", str(getattr(sim, "simulation_start_date", "N/A"))])
        ws_summary.append(["Hash Artefacto Activo Usado", getattr(sim, "artifact_sha256_used", "N/A") or "N/A"])

    for k, v in summary.items():
        ws_summary.append([str(k), str(v)])

    # Sheet 2: Evaluación Experimental (si existe)
    if evaluation:
        ws_eval = wb.create_sheet(title="Evaluación H1 Formal")
        ws_eval.append(["Campo de Evaluación", "Valor"])
        for cell in ws_eval[1]:
            cell.fill = PatternFill(start_color="0284C7", end_color="0284C7", fill_type="solid")
            cell.font = header_font

        ws_eval.append(["ID Evaluación", evaluation.id])
        ws_eval.append(["Simulación Candidata", evaluation.candidate_simulation_id])
        ws_eval.append(["Simulación Base", evaluation.baseline_simulation_id or "Sin baseline"])
        ws_eval.append(["Dataset Observado", evaluation.observed_dataset_id])
        ws_eval.append(["Procedencia", evaluation.source_type])
        ws_eval.append(["Cobertura Observada", f"{evaluation.data_coverage_pct:.1f}%" if evaluation.data_coverage_pct is not None else "N/D"])
        ws_eval.append(["Observaciones Usadas", str(evaluation.observations_count)])
        ws_eval.append(["Solapamiento Calibración", "SÍ" if evaluation.overlap_detected else "NO"])
        ws_eval.append(["Elegible para H1", "SÍ" if evaluation.eligible_for_h1 else "NO"])
        ws_eval.append(["MAPE Candidato", f"{evaluation.mape_candidate:.2f}%" if evaluation.mape_candidate is not None else "Pendiente"])
        ws_eval.append(["MAPE Base", f"{evaluation.mape_baseline:.2f}%" if evaluation.mape_baseline is not None else "Pendiente"])
        ws_eval.append(["Delta MAPE (pp)", f"{evaluation.delta_mape_pp:.2f}" if evaluation.delta_mape_pp is not None else "Pendiente"])
        ws_eval.append(["RMSE Candidato", f"{evaluation.rmse_candidate:.2f}" if evaluation.rmse_candidate is not None else "Pendiente"])
        ws_eval.append(["R² Candidato", f"{evaluation.r2_candidate:.4f}" if evaluation.r2_candidate is not None else "Pendiente"])
        ws_eval.append(["Wilcoxon p-value", f"{evaluation.wilcoxon_p_value:.6f}" if evaluation.wilcoxon_p_value is not None else "Pendiente"])
        ws_eval.append(["Estado H1", evaluation.h1_status])
        ws_eval.append(["Conclusión Científica", evaluation.scientific_conclusion or "Pendiente"])

    # Sheet 3: Condados (si existen)
    if county_data:
        ws_counties = wb.create_sheet(title="Detalle 47 Condados")
        ws_counties.append(["Código", "Nombre", "Población", "Casos Totales", "Muertes", "Pico Infecciones", "Camas UCI", "Saturación UCI"])
        for cell in ws_counties[1]:
            cell.fill = PatternFill(start_color="0369A1", end_color="0369A1", fill_type="solid")
            cell.font = header_font
        for c in county_data:
            ws_counties.append([
                c.get("code"),
                c.get("name"),
                c.get("population"),
                c.get("total_cases"),
                c.get("total_deaths"),
                c.get("peak_infected"),
                c.get("icu_beds_verified") if c.get("icu_beds_verified") is not None else "No Verif.",
                "SÍ" if c.get("icu_saturated") else "NO"
            ])

    buffer = io.BytesIO()
    wb.save(buffer)
    excel_bytes = buffer.getvalue()
    buffer.close()

    content_hash = hashlib.sha256(excel_bytes).hexdigest()

    audit_entry = AuditLogDB(
        id=f"aud-{uuid.uuid4().hex[:12]}",
        user_id=current_user.id,
        user_email=current_user.email,
        user_role=current_user.role,
        action="EXPORT_EXCEL_BY_ID",
        parameters_hash=content_hash,
        seed=42,
        execution_time_ms=35,
        details=json.dumps({
            "target_simulation_id": req.simulation_id,
            "target_evaluation_id": req.evaluation_id,
            "excel_size_bytes": len(excel_bytes),
            "sha256": content_hash
        })
    )
    db.add(audit_entry)
    db.commit()

    return Response(
        content=excel_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=Dossier_Kenia_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.xlsx",
            "X-Content-SHA256": content_hash
        }
    )


@router.post("/export/pdf")
def export_pdf(
    req: ExportReportRequest,
    db: Session = Depends(get_db),
    current_user: UserDB = Depends(get_current_user)
):
    """Endpoint de exportación PDF legacy compatible con frontend existente."""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=36,
        leftMargin=36,
        topMargin=36,
        bottomMargin=36
    )

    is_demo = req.is_demo or req.is_synthetic
    story = _build_pdf_story(
        title=req.title or "Informe Epidemiológico - Gemelo Digital",
        user_name=current_user.name,
        user_role=current_user.role,
        is_demo=is_demo,
        summary=req.national_summary or {},
        evaluation=None
    )
    doc.build(story)
    pdf_bytes = buffer.getvalue()
    buffer.close()

    content_hash = hashlib.sha256(pdf_bytes).hexdigest()

    audit_entry = AuditLogDB(
        id=f"aud-{uuid.uuid4().hex[:12]}",
        user_id=current_user.id,
        user_email=current_user.email,
        user_role=current_user.role,
        action="EXPORT_PDF",
        parameters_hash=content_hash,
        seed=42,
        execution_time_ms=45,
        details=json.dumps({"title": req.title, "is_demo": is_demo, "size_bytes": len(pdf_bytes)})
    )
    db.add(audit_entry)
    db.commit()

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename=Informe_Kenia_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.pdf",
            "X-Content-SHA256": content_hash
        }
    )


@router.post("/export/excel")
def export_excel(
    req: ExportReportRequest,
    db: Session = Depends(get_db),
    current_user: UserDB = Depends(get_current_user)
):
    """Endpoint de exportación Excel legacy compatible con frontend existente."""
    wb = openpyxl.Workbook()
    header_font = Font(name="Arial", size=10, bold=True, color="FFFFFF")

    # Sheet 1: Resumen
    ws_summary = wb.active
    ws_summary.title = "Resumen Nacional"
    ws_summary.append(["Indicador", "Valor"])
    for cell in ws_summary[1]:
        cell.fill = PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")
        cell.font = header_font

    if req.national_summary:
        for k, v in req.national_summary.items():
            ws_summary.append([k, v])

    # Sheet 2: Condados
    if req.county_results:
        ws_counties = wb.create_sheet(title="Detalle 47 Condados")
        ws_counties.append(["Código", "Nombre", "Población", "Casos Totales", "Muertes", "Pico Infecciones", "Camas UCI", "Saturación UCI"])
        for cell in ws_counties[1]:
            cell.fill = PatternFill(start_color="0284C7", end_color="0284C7", fill_type="solid")
            cell.font = header_font
        for c in req.county_results:
            ws_counties.append([
                c.get("code"),
                c.get("name"),
                c.get("population"),
                c.get("total_cases"),
                c.get("total_deaths"),
                c.get("peak_infected"),
                c.get("icu_beds_verified") if c.get("icu_beds_verified") is not None else "No Verif.",
                "SÍ" if c.get("icu_saturated") else "NO"
            ])

    buffer = io.BytesIO()
    wb.save(buffer)
    excel_bytes = buffer.getvalue()
    buffer.close()

    content_hash = hashlib.sha256(excel_bytes).hexdigest()

    audit_entry = AuditLogDB(
        id=f"aud-{uuid.uuid4().hex[:12]}",
        user_id=current_user.id,
        user_email=current_user.email,
        user_role=current_user.role,
        action="EXPORT_EXCEL",
        parameters_hash=content_hash,
        seed=42,
        execution_time_ms=30,
        details=json.dumps({"title": req.title, "excel_size_bytes": len(excel_bytes), "is_demo": req.is_demo or req.is_synthetic})
    )
    db.add(audit_entry)
    db.commit()

    return Response(
        content=excel_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=Datos_Epidemiologicos_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.xlsx",
            "X-Content-SHA256": content_hash
        }
    )
