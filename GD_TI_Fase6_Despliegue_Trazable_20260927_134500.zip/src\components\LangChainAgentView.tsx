import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  Database, 
  TrendingUp, 
  Bot, 
  Layers, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Cpu, 
  FileCode2, 
  Wrench,
  Info
} from 'lucide-react';

interface LangChainToolCall {
  tool_name: string;
  args: Record<string, any>;
  output_summary: string;
}

interface LangChainMetadata {
  framework: string;
  execution_mode: string;
  orchestration_type: string;
  components_executed: string[];
  tools_invoked: LangChainToolCall[];
  provider: string;
  execution_time_ms: number;
}

interface LangChainResponse {
  query: string;
  cutoff_date: string;
  database_observations: Record<string, any>;
  model_forecasts: Record<string, any>;
  hospital_capacity: Record<string, any>;
  generated_text: string;
  langchain_metadata: LangChainMetadata;
}

interface LangChainAgentViewProps {
  darkMode: boolean;
}

export const LangChainAgentView: React.FC<LangChainAgentViewProps> = ({ darkMode }) => {
  const [query, setQuery] = useState('¿Cuál es la proyección de vigilancia y la capacidad hospitalaria para el corte dominical?');
  const [cutoffDate, setCutoffDate] = useState('2024-07-28');
  const [countyCode, setCountyCode] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<LangChainResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const suggestedQueries = [
    '¿Cuál es el pronóstico nacional y la capacidad de camas UCI registrada para el condado?',
    'Compara la persistencia nacional con la sensibilidad de Random Forest para este corte',
    '¿Qué infraestructura descriptiva de camas UCI registra Kiambu frente a los datos nacionales?',
  ];

  const handleQuery = async (customQuery?: string) => {
    const q = customQuery || query;
    if (!q.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const resp = await fetch('http://localhost:8000/api/v1/langchain-agent/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: q,
          cutoff_date: cutoffDate,
          county_code: countyCode,
        }),
      });

      if (!resp.ok) {
        throw new Error(`Error ${resp.status}: ${await resp.text()}`);
      }

      const data: LangChainResponse = await resp.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Error de conexión con el endpoint LangChain');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Encabezado */}
      <div className={`p-6 rounded-2xl border ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'} shadow-sm`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                <Sparkles size={20} />
              </span>
              <h2 className="text-xl font-bold tracking-tight">
                Agente Integrador LangChain
              </h2>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                LCEL Pipeline • Tools @tool
              </span>
            </div>
            <p className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Caso integrador verificable en Python con componentes de LangChain (<code className="font-mono text-purple-400">langchain_core</code>). Ejecuta herramientas estructuradas, prompt templates y LCEL, con estricta segregación de observaciones empíricas, pronósticos y síntesis estructurada.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Selector de Condado */}
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-medium text-slate-400">Ámbito:</span>
              <select
                id="select_langchain_county"
                value={countyCode}
                onChange={(e) => setCountyCode(Number(e.target.value))}
                className={`text-xs px-2.5 py-1.5 rounded-xl border font-mono ${
                  darkMode ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-slate-100 border-slate-300 text-slate-800'
                }`}
              >
                <option value={0}>Nacional (KEN)</option>
                <option value={47}>Nairobi City (47)</option>
                <option value={22}>Kiambu (22)</option>
                <option value={32}>Nakuru (32)</option>
                <option value={28}>Mombasa (28)</option>
              </select>
            </div>

            {/* Selector de Fecha */}
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-medium text-slate-400">Corte:</span>
              <select
                id="select_langchain_cutoff"
                value={cutoffDate}
                onChange={(e) => setCutoffDate(e.target.value)}
                className={`text-xs px-2.5 py-1.5 rounded-xl border font-mono ${
                  darkMode ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-slate-100 border-slate-300 text-slate-800'
                }`}
              >
                <option value="2024-07-28">2024-07-28 (Test Final)</option>
                <option value="2024-07-21">2024-07-21 (Test Penúltimo)</option>
                <option value="2023-04-02">2023-04-02 (Inicio Test)</option>
                <option value="2022-12-18">2022-12-18 (Validación)</option>
                <option value="2021-07-11">2021-07-11 (Entrenamiento)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Input de Consulta */}
        <div className="mt-4 flex flex-col sm:flex-row gap-2">
          <input
            id="input_langchain_query"
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleQuery()}
            placeholder="Ingrese una pregunta epidemiológica para el agente LangChain..."
            className={`flex-1 px-4 py-2.5 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-purple-500/40 ${
              darkMode ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
          <button
            id="btn_execute_langchain_agent"
            onClick={() => handleQuery()}
            disabled={loading}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-purple-500/20 disabled:opacity-50 cursor-pointer"
          >
            {loading ? <Clock className="animate-spin" size={14} /> : <Send size={14} />}
            <span>Ejecutar LangChain</span>
          </button>
        </div>

        {/* Consultas Sugeridas */}
        <div className="mt-3 flex flex-wrap gap-2">
          <span className="text-[10px] text-slate-500 self-center">Sugerencias:</span>
          {suggestedQueries.map((sq, idx) => (
            <button
              key={idx}
              onClick={() => {
                setQuery(sq);
                handleQuery(sq);
              }}
              className={`text-[11px] px-2.5 py-1 rounded-lg border transition cursor-pointer ${
                darkMode
                  ? 'bg-slate-800/80 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                  : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {sq}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
          <AlertTriangle size={16} className="shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* RESULTADOS EN 3 PANELES SEGREGADOS + PANEL DE METADATOS LANGCHAIN */}
      {result && (
        <div className="space-y-4">
          {/* Banner Metodológico: Delimitación Nacional vs Capacidad Condal Descriptiva */}
          <div className={`p-3.5 rounded-xl border text-[11px] flex items-start gap-2.5 ${
            darkMode ? 'bg-indigo-950/30 border-indigo-800/50 text-indigo-200' : 'bg-indigo-50 border-indigo-200 text-indigo-900'
          }`}>
            <Info size={16} className="text-indigo-400 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong>Delimitación Epidemiológica y Hospitalaria:</strong> Las cifras de casos observados ({result.database_observations.observed_weekly_cases} casos) y pronósticos ({result.model_forecasts.persistence_prediction_cases} casos) son de nivel <strong>NACIONAL (Kenia, KEN, county_code=0)</strong>. Las camas UCI mostradas corresponden al inventario <strong>descriptivo referencial no verificado del condado</strong> (ej. Kiambu: 24 camas en relevamiento preliminar; no coincide con Barasa et al. 2020 PLOS ONE S1 Table, que registra 16 camas totales; calificación de verificada retirada). <em>No existe desagregación condal de casos ni modelo de conversión clínica a ingresos UCI que permita inferir saturación o no saturación hospitalaria en Kiambu.</em>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Panel 1: Observaciones de la Base (Azul) */}
            <div className={`p-5 rounded-2xl border ${darkMode ? 'bg-blue-950/20 border-blue-900/50' : 'bg-blue-50 border-blue-200'}`}>
              <div className="flex items-center gap-2 mb-3">
                <span className="p-1.5 rounded-lg bg-blue-500/20 text-blue-400">
                  <Database size={16} />
                </span>
                <h3 className="text-xs font-bold text-blue-400 uppercase tracking-wider font-mono">
                  1. Observaciones SQLite (Nacional KEN, @tool)
                </h3>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between border-b border-blue-800/20 pb-1">
                  <span className="text-slate-400">Fecha de Corte:</span>
                  <span className="font-mono font-bold">{result.database_observations.date}</span>
                </div>
                <div className="flex justify-between border-b border-blue-800/20 pb-1">
                  <span className="text-slate-400">Casos Nacionales ($y_t$):</span>
                  <span className="font-mono font-bold text-blue-300">{result.database_observations.observed_weekly_cases} casos</span>
                </div>
                <div className="flex justify-between border-b border-blue-800/20 pb-1">
                  <span className="text-slate-400">Muertes Nacionales:</span>
                  <span className="font-mono">{result.database_observations.observed_weekly_deaths}</span>
                </div>
                <div className="flex justify-between border-b border-blue-800/20 pb-1">
                  <span className="text-slate-400">Índice Rigurosidad:</span>
                  <span className="font-mono">{result.database_observations.stringency_index_lag1}</span>
                </div>
                <div className="pt-1">
                  <span className="text-[10px] text-blue-400/80 font-mono">
                    ✓ Invocado: tool_query_observations
                  </span>
                </div>
              </div>
            </div>

            {/* Panel 2: Pronósticos del Modelo (Verde/Ámbar) */}
            <div className={`p-5 rounded-2xl border ${darkMode ? 'bg-emerald-950/20 border-emerald-900/50' : 'bg-emerald-50 border-emerald-200'}`}>
              <div className="flex items-center gap-2 mb-3">
                <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
                  <TrendingUp size={16} />
                </span>
                <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider font-mono">
                  2. Pronósticos Estadísticos (Nacional KEN, @tool)
                </h3>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between border-b border-emerald-800/20 pb-1">
                  <span className="text-slate-400">Semana Proyectada ($t+1$):</span>
                  <span className="font-mono font-bold">{result.model_forecasts.target_week}</span>
                </div>
                <div className="flex justify-between border-b border-emerald-800/20 pb-1">
                  <span className="text-slate-400">Persistencia Naive (Nacional KEN):</span>
                  <span className="font-mono font-bold text-emerald-400">
                    {result.model_forecasts.persistence_prediction_cases} casos
                  </span>
                </div>
                <div className="flex justify-between border-b border-emerald-800/20 pb-1">
                  <span className="text-slate-400">Observado Real Nacional ($t+1$):</span>
                  <span className="font-mono font-bold">
                    {result.model_forecasts.observed_target_actual !== null 
                      ? `${result.model_forecasts.observed_target_actual} casos` 
                      : 'No disponible'}
                  </span>
                </div>
                <div className="flex justify-between border-b border-emerald-800/20 pb-1">
                  <span className="text-slate-400">RF Nacional (Sensibilidad):</span>
                  <span className="font-mono text-amber-400">
                    {result.model_forecasts.random_forest_sensitivity_cases} casos
                  </span>
                </div>
                <div className="pt-1">
                  <span className="text-[10px] text-amber-400/80 font-mono">
                    ⚠ Sensibilidad no causal sobre variables congeladas
                  </span>
                </div>
              </div>
            </div>

            {/* Panel 3: Texto Generado por LangChain (Púrpura) */}
            <div className={`p-5 rounded-2xl border ${darkMode ? 'bg-purple-950/20 border-purple-900/50' : 'bg-purple-50 border-purple-200'}`}>
              <div className="flex items-center gap-2 mb-3">
                <span className="p-1.5 rounded-lg bg-purple-500/20 text-purple-400">
                  <Bot size={16} />
                </span>
                <h3 className="text-xs font-bold text-purple-400 uppercase tracking-wider font-mono">
                  3. Síntesis LangChain Core
                </h3>
              </div>
              <div className="text-xs space-y-2 whitespace-pre-wrap leading-relaxed font-sans max-h-56 overflow-y-auto pr-1">
                {result.generated_text}
              </div>
            </div>
          </div>

          {/* Panel 4: Metadatos Transparentes de LangChain */}
          <div className={`p-5 rounded-2xl border ${darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-100 border-slate-300'}`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-2 border-b border-slate-700/40">
              <div className="flex items-center gap-2">
                <Cpu size={16} className="text-purple-400" />
                <h3 className="text-xs font-bold font-mono uppercase tracking-wider text-slate-300">
                  Trazabilidad de Ejecución LangChain (Backend FastAPI)
                </h3>
              </div>
              <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
                <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  Modo: {result.langchain_metadata.execution_mode}
                </span>
                <span className="text-slate-400 flex items-center gap-1">
                  <Clock size={12} /> {result.langchain_metadata.execution_time_ms} ms
                </span>
              </div>
            </div>

            {/* Explicación Técnica del Modo */}
            <div className={`p-3 rounded-xl mb-4 text-[11px] flex items-start gap-2 ${
              darkMode ? 'bg-slate-950/50 text-slate-300 border border-slate-800' : 'bg-white text-slate-700 border border-slate-200'
            }`}>
              <Info size={15} className="text-purple-400 shrink-0 mt-0.5" />
              <div>
                <strong>Orquestación:</strong> {result.langchain_metadata.orchestration_type}.<br />
                <strong>Ejecutor:</strong> {result.langchain_metadata.provider}. Las herramientas están estructuradas mediante <code className="font-mono text-purple-400">@tool</code> de LangChain Core y son invocadas de forma orquestada por el pipeline.
              </div>
            </div>

            {/* Componentes de LangChain Ejecutados */}
            <div className="mb-4">
              <span className="text-[11px] font-mono text-slate-400 block mb-1.5 font-bold">
                Componentes LangChain Ejecutados en Pipeline LCEL:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {result.langchain_metadata.components_executed.map((comp, idx) => (
                  <span
                    key={idx}
                    className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-slate-800 text-slate-300 border border-slate-700/80 flex items-center gap-1"
                  >
                    <FileCode2 size={11} className="text-purple-400" />
                    {comp}
                  </span>
                ))}
              </div>
            </div>

            {/* Herramientas Invocadas */}
            <div>
              <span className="text-[11px] font-mono text-slate-400 block mb-1.5 font-bold">
                Herramientas Estructuradas (@tool) Invocadas:
              </span>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {result.langchain_metadata.tools_invoked.map((t, idx) => (
                  <div
                    key={idx}
                    className={`p-2.5 rounded-xl border text-[11px] ${
                      darkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="font-mono font-bold text-purple-400 flex items-center gap-1 mb-1">
                      <Wrench size={12} />
                      {t.tool_name}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono mb-1 truncate">
                      Args: {JSON.stringify(t.args)}
                    </div>
                    <div className="text-[10px] text-slate-300">
                      {t.output_summary}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
