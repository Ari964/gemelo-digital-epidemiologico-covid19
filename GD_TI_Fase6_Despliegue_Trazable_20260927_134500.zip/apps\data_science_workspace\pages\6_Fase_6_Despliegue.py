import sys
import streamlit as st
import json
import os
import requests
import pandas as pd

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from auth_helper import render_auth_sidebar, api_call

st.set_page_config(page_title="Fase 6: Despliegue y Monitoreo | CRISP-DM", page_icon="🚀", layout="wide")
render_auth_sidebar()

st.title("🚀 Fase 6 (CRISP-DM) - Despliegue Operativo y Monitoreo de Modelos")
st.caption("Gestión del Modelo Activo (Singleton), Activación Trazable, Monitoreo On-Demand de Drift y Enlace al Frontend React")

tab1, tab2, tab3 = st.tabs([
    "🟢 Modelo Activo en Despliegue",
    "📡 Monitoreo On-Demand (Estabilidad y Drift)",
    "🔗 Enlace Operativo con Frontend React"
])

with tab1:
    st.subheader("Estado del Despliegue Operativo (Singleton)")
    st.markdown("""
    En la metodología CRISP-DM, la fase de despliegue asegura que únicamente modelos aprobados técnicamente
    sean activados como motor operativo del Gemelo Digital.
    """)

    # Consultar modelo activo del backend
    active_data = None
    try:
        r = api_call("GET", "/validation/active-model")
        if r.status_code == 200:
            active_data = r.json()
        elif r.status_code == 401:
            st.info("Inicie sesión en el sidebar para visualizar el estado del modelo operativo.")
    except Exception:
        active_data = None

    if active_data and active_data.get("has_active_model"):
        model_info = active_data.get("active_model", {})
        st.success(f"✅ Modelo Operativo Activo: **{model_info.get('name')}** (Versión `{model_info.get('version')}`)")
        c1, c2, c3 = st.columns(3)
        c1.metric("Versión Desplegada", model_info.get("version"))
        c2.metric("Fecha de Activación", str(model_info.get("deployed_at", ""))[:19])
        c3.metric("Activado Por", model_info.get("deployed_by", "Sistema"))

        st.markdown("#### Hash de Integridad del Artefacto Desplegado:")
        st.code(model_info.get("artifact_sha256") or "Sin hash registrado")
        st.caption("Artefacto verificado con hash SHA-256 en disco.")
    else:
        st.warning("⚠️ NO_ACTIVE_MODEL_DEPLOYED: Actualmente no hay un modelo operativo activado en producción.")
        st.info("Para activar un modelo, se debe contar previamente con una evaluación aprobada técnicamente.")

    st.markdown("---")
    st.markdown("#### Activación de Modelo para Uso Operativo")
    with st.form("activation_form"):
        ver_to_activate = st.text_input("Versión del Modelo a Activar:", placeholder="v2026...")
        act_notes = st.text_area("Notas de Despliegue Operativo:", value="Pase a producción tras validación y aprobación técnica de ingeniería.")
        submit_act = st.form_submit_button("Activar Modelo en Producción (Transacción Atómica)")

        if submit_act:
            if not ver_to_activate.strip():
                st.error("Ingrese una versión válida registrada.")
            else:
                try:
                    resp = api_call("POST", "/validation/activate-model", json_data={
                        "version": ver_to_activate.strip(),
                        "notes": act_notes
                    })
                    if resp.status_code == 200:
                        res = resp.json()
                        st.success(f"🎉 Modelo {res.get('version')} activado exitosamente en producción.")
                        st.rerun()
                    elif resp.status_code == 400:
                        st.error(f"Rechazo: {resp.json().get('detail')}")
                    elif resp.status_code == 401:
                        st.error("🔒 No autenticado. Inicie sesión como Administrador o Epidemiólogo.")
                    elif resp.status_code == 403:
                        st.error("🚫 Permisos insuficientes. Se requiere rol Admin o Epidemiólogo.")
                    else:
                        st.error(f"Error ({resp.status_code}): {resp.text}")
                except Exception as e:
                    st.error(f"Error al activar modelo: {e}")

    st.markdown("---")
    st.markdown("#### Historial de Activaciones y Despliegues")
    hist_data = []
    try:
        r_h = api_call("GET", "/validation/activations/history")
        if r_h.status_code == 200:
            hist_data = r_h.json()
    except Exception:
        hist_data = []

    if hist_data:
        st.dataframe(pd.DataFrame([{
            "ID Activación": h["id"],
            "Versión": h["version"],
            "Acción": h.get("action", "ACTIVATE"),
            "Versión Previa": h.get("previous_version") or "Ninguna",
            "Activado Por": h["activated_by"],
            "Fecha Activación": str(h["activated_at"])[:19],
            "Notas": h.get("notes") or ""
        } for h in hist_data]), use_container_width=True)
    else:
        st.caption("No se registran eventos previos de activación.")

with tab2:
    st.subheader("Monitoreo On-Demand de Población y Deriva (Drift)")
    st.info("Denominación Metodológica: **Monitoreo Manual / On-Demand**. Separación estricta entre: Insumos (Data Drift), Salidas (Output Stability) y Desempeño (Predictive Degradation).")

    # Ejecutar evaluación manual de monitoreo
    st.markdown("#### Ejecutar Ciclo de Monitoreo Manual")
    col_m1, col_m2 = st.columns(2)
    with col_m1:
        mode_choice = st.selectbox(
            "Modalidad de Monitoreo a Evaluar:",
            ["DATA_DRIFT", "OUTPUT_STABILITY", "PREDICTIVE_DEGRADATION"]
        )
    with col_m2:
        mon_notes = st.text_input("Notas de la auditoría de monitoreo:", value="Revisión periódica de estabilidad poblacional")

    ref_ds_id = None
    curr_ds_id = None
    if mode_choice == "DATA_DRIFT":
        st.caption("Seleccione los datasets a comparar para deriva de datos:")
        c_ds1, c_ds2 = st.columns(2)
        datasets_options = ["(Ninguno)"]
        try:
            r_ds = api_call("GET", "/data/datasets")
            if r_ds.status_code == 200:
                ds_json = r_ds.json()
                ds_items = ds_json.get("datasets", []) if isinstance(ds_json, dict) else ds_json
                datasets_options += [f"{d['id']} | {d.get('name', '')} ({d.get('source_type', 'UNKNOWN')})" for d in ds_items]
        except Exception:
            pass

        with c_ds1:
            sel_ref = st.selectbox("Dataset de Referencia:", datasets_options, index=0)
            if sel_ref != "(Ninguno)":
                ref_ds_id = sel_ref.split(" | ")[0].strip()
        with c_ds2:
            sel_curr = st.selectbox("Dataset Actual:", datasets_options, index=0)
            if sel_curr != "(Ninguno)":
                curr_ds_id = sel_curr.split(" | ")[0].strip()

    if st.button("Ejecutar Monitoreo On-Demand", type="primary"):
        with st.spinner("Calculando métricas de estabilidad y deriva en backend..."):
            try:
                payload = {
                    "monitoring_mode": mode_choice,
                    "notes": mon_notes
                }
                if ref_ds_id:
                    payload["reference_dataset_id"] = ref_ds_id
                if curr_ds_id:
                    payload["current_dataset_id"] = curr_ds_id

                m_resp = api_call("POST", "/monitoring/evaluate", json_data=payload)
                if m_resp.status_code == 200:
                    st.success("Evaluación de monitoreo completada.")
                    st.rerun()
                elif m_resp.status_code == 401:
                    st.error("🔒 No autenticado. Inicie sesión en el sidebar.")
                elif m_resp.status_code == 403:
                    st.error("🚫 Permisos insuficientes. Se requiere rol Admin o Epidemiólogo.")
                else:
                    st.error(f"Error ({m_resp.status_code}): {m_resp.text}")
            except Exception as e:
                st.error(f"Fallo de conexión: {e}")

    st.markdown("---")
    st.markdown("#### Último Estado de Monitoreo Registrado")
    mon_status = None
    try:
        r_m = api_call("GET", "/monitoring/status")
        if r_m.status_code == 200:
            mon_status = r_m.json()
    except Exception:
        mon_status = None

    if mon_status:
        st.markdown(f"**Modalidad Evaluada:** `{mon_status.get('monitoring_mode')}` | **Estado General:** `{mon_status.get('overall_status')}`")
        if mon_status.get("unavailability_reason"):
            st.warning(f"📌 Motivo de indisponibilidad: {mon_status.get('unavailability_reason')}")

        m1, m2, m3 = st.columns(3)
        psi_v = mon_status.get("psi_value")
        ks_v = mon_status.get("ks_p_value")
        m1.metric("PSI (Population Stability)", f"{psi_v:.4f}" if psi_v is not None else "Pendiente / No disp.")
        m2.metric("Estado PSI", mon_status.get("psi_status") or "No disponible")
        m3.metric("KS p-value", f"{ks_v:.4f}" if ks_v is not None else "Pendiente / No disp.")

        if mon_status.get("alerts"):
            st.markdown("##### Alertas y Diagnóstico:")
            for a in mon_status["alerts"]:
                st.write(f"- {a}")

        if mon_status.get("recommendation"):
            st.info(f"💡 **Recomendación:** {mon_status['recommendation']}")

    st.markdown("---")
    st.markdown("#### Historial de Ciclos de Monitoreo")
    mon_logs = []
    try:
        r_l = api_call("GET", "/monitoring/history")
        if r_l.status_code == 200:
            mon_logs = r_l.json()
    except Exception:
        mon_logs = []

    if mon_logs:
        st.dataframe(pd.DataFrame([{
            "ID Log": l["id"],
            "Fecha": str(l["evaluated_at"])[:19],
            "Versión Modelo": l["model_version"],
            "Estado": l["overall_status"],
            "PSI": f"{l['psi_value']:.4f}" if l.get("psi_value") is not None else "N/D",
            "KS p-val": f"{l['ks_p_value']:.4f}" if l.get("ks_p_value") is not None else "N/D",
            "Notas": l.get("notes") or l.get("unavailability_reason") or ""
        } for l in mon_logs]), use_container_width=True)
    else:
        st.caption("No se registran ciclos previos de monitoreo.")

with tab3:
    st.subheader("Enlace Operativo con Frontend React")
    st.markdown("""
    El frontend principal en React/TypeScript consulta este mismo estado para reflejar en tiempo real
    si el Gemelo Digital opera con un modelo calibrado formalmente o en modo de demostración.
    """)
    st.code(f"""
    // Frontend React consume:
    const activeModel = await ApiClient.getActiveModel();
    const monitoring = await ApiClient.getMonitoringStatus();
    """, language="typescript")
