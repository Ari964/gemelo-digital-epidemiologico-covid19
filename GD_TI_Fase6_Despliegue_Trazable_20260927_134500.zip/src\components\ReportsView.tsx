import React, { useState } from 'react';
import { 
  FileText, 
  FileSpreadsheet, 
  Printer, 
  Download, 
  CheckCircle2, 
  Sparkles,
  Layers,
  FileCheck,
  Shield
} from 'lucide-react';
import { SimulationResult, LanguageCode } from '../types';
import { translations } from '../i18n/translations';
import { KENYA_COUNTIES } from '../data/kenyaCounties';
import { useToast } from './ToastContainer';
import { ApiClient } from '../services/apiClient';

interface ReportsViewProps {
  simulationResult: SimulationResult;
  lang: LanguageCode;
  darkMode: boolean;
  userEmail?: string;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  simulationResult,
  lang,
  darkMode,
  userEmail = 'dr.wanjiku@health.go.ke',
}) => {
  const t = translations[lang];
  const { addToast } = useToast();
  const [selectedTemplate, setSelectedTemplate] = useState<'briefing' | 'tradeoff' | 'validation' | 'equity'>('briefing');
  const [isExporting, setIsExporting] = useState<'pdf' | 'excel' | 'word' | null>(null);

  const summary = simulationResult.summary;

  // Exportar a PDF utilizando el endpoint del backend con ReportLab (/api/v1/reports/export/pdf)
  const handleExportPdfBackend = async () => {
    setIsExporting('pdf');
    try {
      const payload = {
        title: `Dossier Epidemiológico - ${simulationResult.params.name}`,
        simulation_id: simulationResult.auditLogId,
        national_summary: {
          total_cases: summary.totalInfections,
          total_deaths: summary.totalDeaths,
          peak_infections: summary.peakInfected,
          peak_day: summary.peakDay,
          attack_rate: summary.attackRate,
        },
        health_economics: {
          dalys_total: summary.dalysAverted * 3,
          yll: summary.totalDeaths * 12.5,
          yld: summary.totalInfections * 0.05,
          intervention_cost_usd: 1250000,
          intervention_cost_kes: 168750000,
        },
        is_synthetic: simulationResult.isSynthetic || false,
      };

      const blob = await ApiClient.exportPdf(payload);
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Dossier_Epidemiologico_${simulationResult.params.pathogen}_${new Date().toISOString().slice(0, 10)}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      addToast('success', 'Informe PDF Generado (ReportLab)', 'Dossier institucional descargado y registrado en la bitácora de auditoría.');
    } catch (err: any) {
      window.print();
      addToast('info', 'Impresión de Informe', 'Abriendo diálogo de impresión PDF del navegador.');
    } finally {
      setIsExporting(null);
    }
  };

  // Exportar a Excel utilizando el endpoint del backend con OpenPyXL (/api/v1/reports/export/excel)
  const handleExportExcelBackend = async () => {
    setIsExporting('excel');
    try {
      const payload = {
        title: `Datos Epidemiológicos - ${simulationResult.params.name}`,
        simulation_id: simulationResult.auditLogId,
        national_summary: {
          total_cases: summary.totalInfections,
          total_deaths: summary.totalDeaths,
          peak_infections: summary.peakInfected,
          peak_day: summary.peakDay,
          attack_rate: summary.attackRate,
        },
        health_economics: {
          dalys_total: summary.dalysAverted * 3,
          intervention_cost_usd: 1250000,
          intervention_cost_kes: 168750000,
        },
        household_equity: {
          demographic_parity_ratio: summary.demographicParityRatio,
          equity_assessment: summary.demographicParityRatio >= 0.8 && summary.demographicParityRatio <= 1.2 ? 'EQUITATIVO' : 'DESFAVORECE_VULNERABLES',
        },
        is_synthetic: simulationResult.isSynthetic || false,
      };

      const blob = await ApiClient.exportExcel(payload);
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Simulacion_Epidemiologica_${simulationResult.params.pathogen}_${new Date().toISOString().slice(0, 10)}.xlsx`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      addToast('success', 'Planilla Excel Generada (OpenPyXL)', 'Libro de cálculo descargado con formato oficial y registro en bitácora.');
    } catch (err: any) {
      handleExportXlsxLocal();
    } finally {
      setIsExporting(null);
    }
  };

  // Fallback local para Excel
  const handleExportXlsxLocal = () => {
    const rows = simulationResult.nationalTrajectory.map((p) =>
      `<Row>
        <Cell><Data ss:Type="Number">${p.day}</Data></Cell>
        <Cell><Data ss:Type="String">${p.date}</Data></Cell>
        <Cell><Data ss:Type="Number">${p.susceptible}</Data></Cell>
        <Cell><Data ss:Type="Number">${p.exposed}</Data></Cell>
        <Cell><Data ss:Type="Number">${p.infected}</Data></Cell>
        <Cell><Data ss:Type="Number">${p.recovered}</Data></Cell>
        <Cell><Data ss:Type="Number">${p.deceased}</Data></Cell>
        <Cell><Data ss:Type="Number">${p.dailyNewCases}</Data></Cell>
        <Cell><Data ss:Type="Number">${p.icuActive}</Data></Cell>
        <Cell><Data ss:Type="Number">${p.rt}</Data></Cell>
      </Row>`
    ).join('');

    const headers = t.reportHeader.split(',').map((h) =>
      `<Cell ss:StyleID="hdr"><Data ss:Type="String">${h}</Data></Cell>`
    ).join('');

    const xml = `<?xml version="1.0"?>
      <?mso-application progid="Excel.Sheet"?>
      <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
        xmlns:o="urn:schemas-microsoft-com:office:office"
        xmlns:x="urn:schemas-microsoft-com:office:excel"
        xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
        xmlns:html="http://www.w3.org/TR/REC-html40">
        <Styles>
          <Style ss:ID="hdr">
            <Font ss:Bold="1" ss:Color="#FFFFFF"/>
            <Interior ss:Color="#2563EB" ss:Pattern="Solid"/>
          </Style>
        </Styles>
        <Worksheet ss:Name="${simulationResult.params.pathogen.toUpperCase()}">
          <Table>
            <Row>${headers}</Row>
            ${rows}
          </Table>
        </Worksheet>
      </Workbook>`;

    const blob = new Blob(['\ufeff', xml], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${t.reportFileNameData}_${simulationResult.params.pathogen}_${new Date().toISOString().slice(0, 10)}.xlsx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast('info', 'Excel Generado (Local)', 'Planilla generada con motor local.');
  };

  // Descarga en formato Word / Doc
  const handleExportWordDoc = () => {
    setIsExporting('word');
    const docHtml = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head><title>${simulationResult.params.name}</title>
      <meta charset="utf-8" />
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #1e293b; padding: 40px; }
        h1 { color: #1e40af; border-bottom: 2px solid #3b82f6; padding-bottom: 8px; }
        h2 { color: #1e3a8a; margin-top: 24px; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; margin-bottom: 24px; }
        th, td { border: 1px solid #cbd5e1; padding: 8px 12px; text-align: left; }
        th { background-color: #f1f5f9; }
      </style>
      </head>
      <body>
        <h1>${t.reportDocHeader}</h1>
        <p><strong>${t.reportTechReport}:</strong> ${simulationResult.params.name}</p>
        <p><strong>${t.reportPathogen}:</strong> ${simulationResult.params.pathogen.toUpperCase()} | <strong>Fecha:</strong> ${new Date().toUTCString()}</p>
        <h2>Resumen Ejecutivo</h2>
        <ul>
          <li><strong>Infecciones Totales:</strong> ${summary.totalInfections.toLocaleString()} (${summary.attackRate}%)</li>
          <li><strong>Pico de Demanda UCI:</strong> ${summary.peakIcuBedDemand.toLocaleString()} (Capacidad: ${summary.totalIcuCapacity})</li>
          <li><strong>Mortalidad Total:</strong> ${summary.totalDeaths.toLocaleString()}</li>
          <li><strong>DALYs Evitados:</strong> ${summary.dalysAverted.toLocaleString()}</li>
          <li><strong>Razón de Paridad Demográfica (Equidad):</strong> ${summary.demographicParityRatio}x</li>
        </ul>
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff', docHtml], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${t.reportFileNameWord}_${simulationResult.params.pathogen}_${new Date().toISOString().slice(0, 10)}.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      setIsExporting(null);
      addToast('success', 'Documento Word Generado', 'Minuta técnica descargada.');
    }, 500);
  };

  const templates = [
    { id: 'briefing' as const, name: 'Minuta de Políticas (MoH)', desc: 'Resumen ejecutivo de alto nivel para ministros con DALYs y saturación hospitalaria' },
    { id: 'tradeoff' as const, name: 'Evaluación de Trade-offs', desc: 'Análisis de impacto económico vs reducción de mortalidad por intervenciones NPIs' },
    { id: 'validation' as const, name: 'Dossier de Validación', desc: 'Reporte de rigor estadístico con pruebas KS, Anderson-Darling y MAPE 2020-2024' },
    { id: 'equity' as const, name: 'Auditoría de Equidad (DHS)', desc: 'Desglose de paridad demográfica de vacunación y saneamiento en quintiles Q1–Q5' },
  ];

  return (
    <div id="reports_view" className="space-y-6 w-full">
      {/* Encabezado Principal CRISP-DM Transversal */}
      <div className={`p-6 rounded-2xl border ${darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'} shadow-xl flex flex-col md:flex-row items-center justify-between gap-4`}>
        <div>
          <div className="flex items-center gap-2 mb-1">
            <FileText size={22} className="text-blue-400" />
            <h3 className={`text-base font-bold ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              Generación de Informes (Reporting)
            </h3>
          </div>
          <p className={`text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            Módulo transversal consolidado para exportar resultados de cualquier simulación o evaluación a PDF (ReportLab) y Excel (OpenPyXL).
            Artefactos con hash SHA-256 para comprobar integridad y trazabilidad de linaje.
          </p>
        </div>

        {/* BOTONES GRANDES PARA EXPORTAR */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            id="btn_export_pdf_reportlab"
            onClick={handleExportPdfBackend}
            disabled={isExporting === 'pdf'}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 text-white text-xs font-extrabold shadow-lg shadow-blue-500/25 transition cursor-pointer"
          >
            {isExporting === 'pdf' ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Compilando PDF (ReportLab)...
              </>
            ) : (
              <>
                <FileText size={16} />
                Exportar Informe en PDF (ReportLab)
              </>
            )}
          </button>

          <button
            id="btn_export_excel_openpyxl"
            onClick={handleExportExcelBackend}
            disabled={isExporting === 'excel'}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white text-xs font-extrabold shadow-lg shadow-emerald-500/25 transition cursor-pointer"
          >
            {isExporting === 'excel' ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Generando Excel (OpenPyXL)...
              </>
            ) : (
              <>
                <FileSpreadsheet size={16} />
                Exportar Base de Datos en Excel (OpenPyXL)
              </>
            )}
          </button>

          <button
            id="btn_export_word"
            onClick={handleExportWordDoc}
            disabled={isExporting === 'word'}
            className={`flex items-center gap-1.5 px-3.5 py-3 rounded-xl text-xs font-semibold border transition cursor-pointer ${
              darkMode ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700' : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
            }`}
          >
            <Download size={14} />
            Word (.doc)
          </button>
        </div>
      </div>

      {/* Selector de Plantillas */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {templates.map((tmpl) => (
          <button
            id={`tmpl_${tmpl.id}`}
            key={tmpl.id}
            onClick={() => setSelectedTemplate(tmpl.id)}
            className={`p-4 rounded-xl border text-left transition cursor-pointer ${
              selectedTemplate === tmpl.id
                ? 'bg-blue-600/20 border-blue-500 ring-2 ring-blue-500/20 shadow-md'
                : darkMode ? 'bg-slate-900/60 border-slate-800 hover:border-slate-700' : 'bg-white border-slate-200 hover:border-slate-300'
            }`}
          >
            <span className={`text-xs font-bold block mb-1 ${darkMode ? 'text-slate-200' : 'text-slate-800'}`}>
              {tmpl.name}
            </span>
            <span className={`text-[11px] leading-relaxed block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              {tmpl.desc}
            </span>
          </button>
        ))}
      </div>

      {/* Vista Previa del Informe */}
      <div className={`p-6 rounded-2xl border ${darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'} shadow-xl space-y-4`}>
        <div className={`flex items-center justify-between pb-3 border-b ${darkMode ? 'border-slate-800' : 'border-slate-200'}`}>
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-blue-400 font-semibold">
              Vista Previa del Documento a Exportar
            </span>
            <h4 className={`text-base font-bold ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              Dossier de Intervención: {simulationResult.params.name}
            </h4>
          </div>
          <span className={`text-xs font-mono px-3 py-1 rounded-full border ${darkMode ? 'bg-slate-950 border-slate-800 text-slate-300' : 'bg-slate-100 border-slate-300 text-slate-700'}`}>
            Estado: Listo para Descarga
          </span>
        </div>

        <div className="space-y-4 text-xs">
          <p className={`${darkMode ? 'text-slate-300' : 'text-slate-600'} leading-relaxed`}>
            Este expediente técnico sintetiza las proyecciones epidemiológicas del Gemelo Digital Metapoblacional en Kenia, integrando movilidad inter-condados y densidad de hogares bajo la metodología CRISP-DM.
          </p>

          <div className={`grid grid-cols-2 sm:grid-cols-5 gap-3 p-4 rounded-xl border font-mono ${darkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
            <div>
              <span className={`text-[10px] block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>Infecciones Totales</span>
              <strong className="text-blue-400 text-sm">{summary.totalInfections.toLocaleString()}</strong>
            </div>
            <div>
              <span className={`text-[10px] block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>Tasa de Ataque</span>
              <strong className="text-cyan-400 text-sm">{summary.attackRate}%</strong>
            </div>
            <div>
              <span className={`text-[10px] block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>Pico Demanda UCI</span>
              <strong className="text-amber-400 text-sm">{summary.peakIcuBedDemand} camas</strong>
            </div>
            <div>
              <span className={`text-[10px] block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>Fallecidos Totales</span>
              <strong className="text-rose-400 text-sm">{summary.totalDeaths.toLocaleString()}</strong>
            </div>
            <div>
              <span className={`text-[10px] block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>DALYs Evitados</span>
              <strong className="text-emerald-400 text-sm">{summary.dalysAverted.toLocaleString()}</strong>
            </div>
          </div>

          <div className="p-4 rounded-xl border border-blue-500/20 bg-blue-950/10 space-y-2">
            <h5 className="font-bold text-blue-400">Recomendaciones Sanitarias Consolidadas:</h5>
            <ul className={`list-disc list-inside space-y-1 text-[11px] ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
              <li><strong>Priorización en Transporte Público:</strong> Inmunizar a conductores de matatus y comerciantes de mercados abiertos para maximizar el frenado de cadenas de contagio comunitarias.</li>
              <li><strong>Centros de Aislamiento Comunitarios:</strong> En asentamientos densos (Kibera, Mathare), habilitar escuelas y parroquias como centros de aislamiento con provisión de alimentos para evitar la transmisión intra-domicilio.</li>
              <li><strong>Expansión Preventiva de UCI:</strong> La demanda máxima proyectada supera la capacidad basal en condados centrales, requiriendo reubicación de camas de terapia intermedia.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
