import streamlit as st
import json
import os
import sys
import time
import numpy as np
import pandas as pd
from scipy.optimize import minimize

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from auth_helper import render_auth_sidebar, api_call

from backend.app.epidemiology.seir_baseline import SEIRBaselineModel
from backend.app.epidemiology.hybrid_engine import EpidemiologicalDigitalTwin

st.set_page_config(page_title="Fase 4: Modelado | CRISP-DM", page_icon="🧬", layout="wide")
render_auth_sidebar()

st.title("🧬 Fase 4 (CRISP-DM) - Calibración, Modelado Híbrido y Análisis de Sobol")
st.caption("Ajuste de Parámetros con SciPy, Simulación Espacial + ABM y Sensibilidad Global de Saltelli")

# Cargar condados verificados
json_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../backend/app/data/kenya_47_counties_verified.json"))
with open(json_path, "r", encoding="utf-8") as f:
    counties = json.load(f)

tab1, tab2, tab3 = st.tabs([
    "🎛️ Calibración con SciPy (L-BFGS-B)",
    "🚀 Simulación Comparativa (SEIR vs Gemelo Digital)",
    "📊 Análisis de Sensibilidad Global de Sobol (SALib)"
])

with tab1:
    st.subheader("Calibración Numérica de Parámetros (SciPy Optimize)")
    st.markdown("""
    Ajuste de la tasa de transmisión ($\beta$) y período de latencia ($\sigma$) minimizando la suma de errores cuadráticos
    (SSE) mediante el algoritmo **L-BFGS-B** acotado sobre curvas históricas observadas.
    """)
    
    col1, col2 = st.columns(2)
    with col1:
        target_peak_day = st.slider("Día objetivo del pico observado", 30, 90, 48)
        target_peak_cases = st.slider("Casos diarios en el pico", 1000, 20000, 8500)
    
    with col2:
        st.markdown("**Límites de Búsqueda Biológica:**")
        st.write("- $\\beta \\in [0.15, 0.60]$")
        st.write("- $1/\\sigma \\in [3.0, 8.0]$ días de incubación")
        st.write("- $1/\\gamma = 10.0$ días de recuperación fijos")

    if st.button("Ejecutar Calibración SciPy (L-BFGS-B)", type="primary"):
        with st.spinner("Optimizando parámetros epidemiológicos..."):
            # Función de pérdida cuadrática
            def loss_func(params):
                beta, sigma = params
                m = SEIRBaselineModel(beta=beta, sigma=sigma)
                res = m.run(days=100)
                sim_peak = res["peak_infections"]
                sim_day = res["peak_day"]
                # Error ponderado
                err = ((sim_peak - target_peak_cases)/target_peak_cases)**2 + ((sim_day - target_peak_day)/target_peak_day)**2
                return err

            init_guess = [0.35, 1.0/5.2]
            bounds = [(0.15, 0.60), (1.0/8.0, 1.0/3.0)]
            opt_res = minimize(loss_func, init_guess, method='L-BFGS-B', bounds=bounds)

            opt_beta = float(opt_res.x[0])
            opt_sigma = float(opt_res.x[1])

            st.success(f"✅ Calibración completada con éxito ({opt_res.nit} iteraciones L-BFGS-B)")
            c1, c2, c3 = st.columns(3)
            c1.metric("Beta Óptimo (β)", f"{opt_beta:.4f}")
            c2.metric("Período de Incubación Óptimo", f"{1.0/opt_sigma:.2f} días")
            c3.metric("R0 Implícito (β/γ)", f"{opt_beta * 10.0:.2f}")

with tab2:
    st.subheader("Simulación Híbrida: SEIR Espacial Metapoblacional + ABM Intra-Hogar")
    
    c_npi, c_vax, c_mob = st.columns(3)
    with c_npi:
        npi = st.slider("Rigor de Medidas NPI (0 = Ninguna, 1 = Máxima)", 0.0, 1.0, 0.25)
    with c_vax:
        vax = st.slider("Cobertura Vacunal Poblacional", 0.0, 1.0, 0.35)
    with c_mob:
        use_emp = st.checkbox("Utilizar Movilidad Empírica (Meta Data for Good)", value=True)

    if not use_emp:
        st.error("🚨 DATOS SINTÉTICOS ACTIVADOS – Esta simulación no será válida para contraste de H1.")

    if st.button("Lanzar Simulación Híbrida"):
        with st.spinner("Ejecutando Gemelo Digital en 47 condados..."):
            twin = EpidemiologicalDigitalTwin(counties, use_empirical_mobility=use_emp, seed=42)
            results = twin.run_simulation(days=90, npi_stringency=npi, vaccine_coverage=vax)

            summary = results["national_summary"]
            st.markdown("#### Resultados Agregados:")
            k1, k2, k3, k4 = st.columns(4)
            k1.metric("Casos Totales", f"{summary['total_cases']:,}")
            k2.metric("Defunciones Proyectadas", f"{summary['total_deaths']:,}")
            k3.metric("Pico Infecciones Activas", f"{summary['peak_infections']:,}")
            k4.metric("Día Pico", f"Día {summary['peak_day']}")

            # Gráfico de serie temporal
            ts = results["national_time_series"]
            chart_df = pd.DataFrame({
                "Nuevos Casos Diarios": ts["daily_cases"],
                "Infecciones Activas": ts["active_infected"]
            })
            st.line_chart(chart_df)

with tab3:
    st.subheader("Análisis de Sensibilidad Global de Sobol (Flujo Canónico Backend)")
    st.markdown("""
    Cuantifica la contribución de cada parámetro a la varianza del pico de infecciones:
    - **S1 (Primer Orden)**: Efecto directo individual de la variable.
    - **ST (Orden Total)**: Efecto total incluyendo todas las interacciones de orden superior.
    - **Flujo Único Autenticado**: Ejecuta a través de la API REST persistida del backend (`/api/v1/analytics/sobol`).
    """)

    n_sobol = st.select_slider("Muestras Saltelli por variable (N)", options=[64, 128, 256], value=128)

    if st.button("Ejecutar Análisis de Sobol vía Backend API", type="primary"):
        with st.spinner(f"Iniciando análisis de Sobol en el backend (N = {n_sobol})..."):
            try:
                resp = api_call("POST", "/analytics/sobol", json_data={"samples_n": n_sobol, "target_metric": "peak_infections", "seed": 42})
                if resp.status_code in [200, 202]:
                    task = resp.json()
                    analysis_id = task["analysis_id"]
                    st.info(f"Tarea de análisis iniciada: `{analysis_id}`. Estado: `{task['status']}`. Sondeando resultados...")

                    # Sondeo del resultado
                    progress_bar = st.progress(20)
                    sobol_res = None
                    for attempt in range(25):
                        time.sleep(1.0)
                        poll_resp = api_call("GET", f"/analytics/sobol/{analysis_id}")
                        if poll_resp.status_code == 200:
                            sobol_res = poll_resp.json()
                            status = sobol_res.get("status")
                            if status == "COMPLETED":
                                progress_bar.progress(100)
                                break
                            elif status in ["FAILED", "INTERRUPTED"]:
                                st.error(f"El análisis terminó con estado '{status}': {sobol_res.get('error')}")
                                break
                        progress_bar.progress(min(90, 20 + attempt * 3))

                    if sobol_res and sobol_res.get("status") == "COMPLETED":
                        st.success(f"✅ Análisis completado ({sobol_res['total_evaluations']} evaluaciones del modelo)")
                        st.info(f"🏆 Parámetro más influyente: **{sobol_res.get('most_sensitive_parameter')}**")

                        indices = sobol_res.get("indices") or sobol_res.get("sobol_indices") or []
                        if indices:
                            indices_df = pd.DataFrame(indices)
                            st.dataframe(indices_df, use_container_width=True)

                            plot_df = pd.DataFrame({
                                "Parámetro": [p["parameter"] for p in indices],
                                "Primer Orden (S1)": [p["S1"] for p in indices],
                                "Orden Total (ST)": [p["ST"] for p in indices]
                            }).set_index("Parámetro")
                            st.bar_chart(plot_df)
                elif resp.status_code == 401:
                    st.error("🔒 No autenticado (401). Inicie sesión en la barra lateral con rol Admin, Epidemiólogo o Data Scientist.")
                elif resp.status_code == 403:
                    st.error("🚫 Permisos insuficientes (403). Se requiere rol Admin, Epidemiólogo o Data Scientist.")
                else:
                    st.error(f"Error del servidor ({resp.status_code}): {resp.text}")
            except Exception as e:
                st.error(f"Fallo en la comunicación con el backend: {e}")

    st.markdown("---")
    st.markdown("#### Historial de Tareas Sobol en Backend")
    try:
        hist_resp = api_call("GET", "/analytics/sobol")
        if hist_resp.status_code == 200:
            hist = hist_resp.json()
            if hist:
                st.dataframe(pd.DataFrame([{
                    "ID Análisis": h["analysis_id"],
                    "Estado": h["status"],
                    "Muestras/Var": h["samples_per_variable"],
                    "Evaluaciones": h["total_evaluations"],
                    "Parámetro Clave": h.get("most_sensitive_parameter") or "N/D",
                    "Duración (ms)": h.get("duration_ms"),
                    "Creado": str(h.get("created_at"))[:19]
                } for h in hist]), use_container_width=True)
            else:
                st.caption("No se registran tareas previas de Sobol.")
        elif hist_resp.status_code == 401:
            st.caption("Inicie sesión en el sidebar para visualizar el historial de tareas de Sobol.")
    except Exception:
        st.caption("No se pudo contactar el backend para consultar el historial de Sobol.")
