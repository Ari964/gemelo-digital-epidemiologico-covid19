import sys
import streamlit as st
import numpy as np
import pandas as pd
import json
import os
import requests

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from auth_helper import render_auth_sidebar, api_call

from backend.app.analytics.statistics import (
    compute_mape, compute_rmse, compute_r2,
    compare_paired_wilcoxon, kolmogorov_smirnov_2sample,
    compute_icu_saturation_auc_roc
)
from backend.app.analytics.validation_data import ExternalValidationManager

st.set_page_config(page_title="Fase 5: Evaluación | CRISP-DM", page_icon="⚖️", layout="wide")
render_auth_sidebar()

st.title("⚖️ Fase 5 (CRISP-DM) - Evaluación Científica y Aprobación Técnica")
st.caption("Evaluación de Modelos Almacenados, Contraste de H1, Pruebas Bioestadísticas y Gate de Aprobación")

tab1, tab2, tab3 = st.tabs([
    "🔬 Contraste de Hipótesis H1 sobre Evaluaciones Reales",
    "📈 Batería de Pruebas Bioestadísticas",
    "🛡️ Gate de Aprobación Técnica de Modelo (Por ID de Evaluación)"
])

with tab1:
    st.subheader("Contraste Formal de Hipótesis H1 (ΔMAPE ≥ 15.0 pp, p < 0.05)")
    st.markdown("""
    En cumplimiento de la **Regla 5 (Persistir evidencia suficiente para reproducir evaluaciones)** y la **Regla 3 (No fabricar métricas)**,
    esta pantalla permite consultar o registrar evaluaciones vinculando simulación candidata, simulación base y dataset observado verificado.
    """)

    # Consultar evaluaciones existentes del backend
    eval_list = None
    fetch_error = None
    try:
        r = api_call("GET", "/validation/evaluations")
        if r.status_code == 200:
            eval_list = r.json()
        elif r.status_code == 401:
            fetch_error = "Inicie sesión en la barra lateral para visualizar las evaluaciones almacenadas (401 No Autorizado)."
        elif r.status_code == 403:
            fetch_error = "Permisos insuficientes para consultar evaluaciones (403 Prohibido)."
        else:
            fetch_error = f"Error al consultar el backend ({r.status_code}): {r.text}"
    except Exception as ex:
        fetch_error = f"No se pudo contactar al servidor de backend: {ex}"

    if fetch_error:
        st.warning(f"⚠️ {fetch_error}")
    elif eval_list is not None and len(eval_list) > 0:
        st.write(f"Se encontraron **{len(eval_list)}** evaluaciones registradas en el sistema.")
        eval_df = pd.DataFrame([{
            "ID Evaluación": e.get("evaluation_id") or e.get("id"),
            "Candidata": e.get("candidate_simulation_id") or e.get("candidate_sim_id"),
            "Base": e.get("baseline_simulation_id") or e.get("baseline_sim_id") or "Sin baseline",
            "Dataset Obs.": e.get("observed_dataset_id"),
            "Cobertura": f"{e.get('data_coverage_pct', 0.0):.1f}%" if e.get("data_coverage_pct") is not None else "N/D",
            "N Obs": e.get("observations_count", 0),
            "MAPE": f"{e['mape_candidate']:.2f}%" if e.get("mape_candidate") is not None else "Pendiente",
            "RMSE": f"{e['rmse_candidate']:.2f}" if e.get("rmse_candidate") is not None else "Pendiente",
            "R²": f"{e['r2_candidate']:.4f}" if e.get("r2_candidate") is not None else "Pendiente",
            "H1 Estado": e.get("h1_status"),
            "Elegible H1": "SÍ" if e.get("eligible_for_h1") else "NO",
            "Modo Demo": "SÍ" if e.get("is_demo") else "NO"
        } for e in eval_list])
        st.dataframe(eval_df, use_container_width=True)
    elif eval_list is not None and len(eval_list) == 0:
        st.info("No hay evaluaciones registradas en la base de datos (la lista está vacía). Puede registrar una mediante el API formal o ejecutar simulaciones previas.")

    st.markdown("---")
    st.markdown("#### Simulación Interactiva de Contraste H1 (Laboratorio Demostrativo)")
    col_opt1, col_opt2 = st.columns(2)
    with col_opt1:
        data_mode = st.selectbox(
            "Origen de Datos para Prueba de Laboratorio:",
            ["Modo Demostración / Sintético (Bloquea aprobación)", "Serie Observada Simulada (Demostración)"]
        )
        # Todo cálculo interactivo en este laboratorio local es demostrativo y bloquea aprobación formal
        is_demo_mode = True

    with col_opt2:
        n_days = st.slider("Horizonte temporal de evaluación (días)", 30, 180, 90)

    st.warning("⚠️ MODO LABORATORIO DEMOSTRATIVO: Este cálculo local genera series sintéticas. NUNCA produce una acreditación formal de H1 ni habilita el pase a producción.")

    if st.button("Ejecutar Contraste Estadístico en Laboratorio", type="primary"):
        rng = np.random.default_rng(42)
        t = np.linspace(0, 3*np.pi, n_days)
        ground_truth = np.abs(2000 * np.sin(t) + 350 * rng.normal(0, 1, n_days) + 2500)
        seir_pred = ground_truth * rng.uniform(1.30, 1.45, n_days)
        twin_pred = ground_truth * rng.uniform(1.02, 1.08, n_days)

        # compute_mape retorna (float, audit_dict)
        mape_seir_val, _ = compute_mape(ground_truth, seir_pred)
        mape_twin_val, _ = compute_mape(ground_truth, twin_pred)
        delta_mape = (mape_seir_val or 0.0) - (mape_twin_val or 0.0)
        wilc = compare_paired_wilcoxon(ground_truth, twin_pred, seir_pred)

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("MAPE SEIR Clásico", f"{mape_seir_val:.2f}%" if mape_seir_val is not None else "N/D")
        c2.metric("MAPE Gemelo Digital", f"{mape_twin_val:.2f}%" if mape_twin_val is not None else "N/D")
        c3.metric("ΔMAPE", f"{delta_mape:.2f} pp", "Supera 15 pp" if delta_mape >= 15.0 else "No supera")
        wilc_p = wilc.get("p_value")
        c4.metric("Wilcoxon p-value", f"{wilc_p:.4e}" if wilc_p is not None else "N/D", "p < 0.05" if (wilc_p or 1.0) < 0.05 else "p >= 0.05")

        st.error("❌ H1 Estado: BLOCKED_DEMO – La condición demostrativa de laboratorio no permite acreditar H1 formal. La acreditación formal requiere evaluaciones persistidas con datos verificados vía API.")

with tab2:
    st.subheader("Batería de Pruebas Bioestadísticas Formales")
    
    rng = np.random.default_rng(42)
    y_true = rng.uniform(500, 3000, 60)
    y_twin = y_true + rng.normal(0, 50, 60)

    col1, col2, col3 = st.columns(3)
    r2_val = compute_r2(y_true, y_twin)
    rmse_val = compute_rmse(y_true, y_twin)
    mape_val, _ = compute_mape(y_true, y_twin)

    col1.metric("R² Gemelo Digital", f"{r2_val:.4f}" if r2_val is not None else "No disp.")
    col2.metric("RMSE Gemelo Digital", f"{rmse_val:.2f} casos" if rmse_val is not None else "No disp.")
    col3.metric("MAPE Gemelo Digital", f"{mape_val:.2f}%" if mape_val is not None else "No disp.")

    st.markdown("---")
    st.markdown("#### Test de Kolmogorov-Smirnov (2 muestras):")
    ks_res = kolmogorov_smirnov_2sample(y_true, y_twin)
    ks_stat = ks_res.get('statistic')
    ks_p = ks_res.get('p_value')
    ks_stat_str = f"{ks_stat:.4f}" if ks_stat is not None else "N/D"
    ks_p_str = f"{ks_p:.4f}" if ks_p is not None else "N/D"
    st.write(f"- Estadístico KS: `{ks_stat_str}` | p-value: `{ks_p_str}`")
    st.write(f"- Conclusión: {'Distribuciones significativamente distintas' if ks_res.get('distributions_differ') else 'No se rechaza igualdad distributiva'}")

    st.markdown("#### Discriminación Saturación UCI (>90% de Capacidad):")
    y_true_sat = rng.choice([0, 1], size=47, p=[0.75, 0.25])
    y_prob_sat = np.clip(y_true_sat * 0.85 + rng.normal(0.1, 0.1, 47), 0.0, 1.0)
    auc_res = compute_icu_saturation_auc_roc(y_true_sat, y_prob_sat)
    auc_val = auc_res.get('auc_roc')
    auc_str = f"{auc_val:.4f}" if auc_val is not None else "N/D"
    st.metric("AUC-ROC Discriminación Saturación UCI", auc_str)

    st.markdown("---")
    st.markdown("#### Estado de Validación Externa:")
    ext_val = ExternalValidationManager.get_external_validation_status()
    st.info(f"📌 {ext_val['note']}")

with tab3:
    st.subheader("🛡️ Gate de Aprobación Técnica de Ingeniería (Contrato Pydantic v2)")
    st.markdown("""
    En cumplimiento estricto de las reglas:
    - **No se admiten métricas manuales inventadas en el formulario de aprobación.**
    - La aprobación técnica se otorga exclusivamente a un `evaluation_id` persistido que cumpla los criterios biológicos y de datos empíricos.
    """)

    eval_id_input = st.text_input("ID de Evaluación Persistida a Aprobar:", placeholder="eval-...")
    approval_notes = st.text_area("Notas Técnicas del Epidemiólogo Revisor:", value="Revisión de reproducibilidad y ajuste metodológico completada.")

    if st.button("Enviar Solicitud de Aprobación Técnica", type="primary"):
        if not eval_id_input.strip():
            st.error("Debe ingresar un ID de evaluación persistido.")
        else:
            try:
                payload = {
                    "evaluation_id": eval_id_input.strip(),
                    "notes": approval_notes
                }
                with st.spinner("Procesando compuerta técnica de aprobación en backend..."):
                    resp = api_call("POST", "/validation/technical-approval", json_data=payload)
                    if resp.status_code == 200:
                        appr = resp.json()
                        if appr.get("is_approved"):
                            st.success(f"🎉 Modelo aprobado técnicamente. Versión generada: **{appr.get('version')}**")
                            st.info(f"Artefacto generado: `{appr.get('artifact_file')}`\n\nSHA-256: `{appr.get('sha256_checksum')}`")
                        else:
                            st.error("❌ Aprobación rechazada por no cumplir los criterios de ingeniería:")
                            for reason in appr.get("rejection_reasons", []):
                                st.write(f"- {reason}")
                    elif resp.status_code == 401:
                        st.error("🔒 No autenticado (401). Inicie sesión en la barra lateral con credenciales de Administrador o Epidemiólogo.")
                    elif resp.status_code == 403:
                        st.error("🚫 Permisos insuficientes (403). Se requiere rol Admin o Epidemiólogo.")
                    elif resp.status_code == 404:
                        detail = resp.json().get("detail", "Evaluación no encontrada")
                        st.error(f"Error 404: {detail}")
                    else:
                        st.error(f"Error ({resp.status_code}): {resp.text}")
            except Exception as e:
                st.error(f"Error al enviar aprobación: {e}")
