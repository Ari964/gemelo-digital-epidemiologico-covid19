import React from 'react';
import { 
  Shield, 
  Database, 
  Cpu, 
  CheckCircle2, 
  Sliders, 
  FileText, 
  Activity, 
  Columns, 
  Box, 
  Code2, 
  Sun, 
  Moon, 
  Menu, 
  X,
  Sparkles,
  Users,
  TrendingUp,
  Bot
} from 'lucide-react';
import { LanguageCode, UserRole } from '../types';
import { canAccessModule } from '../permissions';

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tabId: string) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  darkMode: boolean;
  onToggleTheme: () => void;
  lang: LanguageCode;
  role: UserRole;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  isCollapsed,
  onToggleCollapse,
  darkMode,
  onToggleTheme,
  lang,
  role,
}) => {
  // Módulos Base estructurados estrictamente según la metodología CRISP-DM
  // y los módulos transversales del sistema de gestión empresarial
  const crispDmModules = [
    {
      id: 'user_security',
      label: 'Gestión de Usuarios y Seguridad',
      shortLabel: 'Seguridad & Usuarios',
      icon: Shield,
      tag: 'CRUD / Audit',
      description: 'CRUD de usuarios, roles (Administrador, Epidemiólogo, Analista) y Bitácora de Auditoría',
    },
    {
      id: 'data_preparation',
      label: 'Fase 1, 2 y 3 (CRISP-DM) - Integración y Preparación de Datos',
      shortLabel: 'Fase 1-3: Integración ETL',
      icon: Database,
      tag: 'ETL / Calidad',
      description: 'Pipeline ETL (Meta Mobility, JHU, DHS), limpieza, imputación y calidad de datos',
    },
    {
      id: 'digital_twin_model',
      label: 'Fase 4 (CRISP-DM) - Gemelo Digital (Modelado)',
      shortLabel: 'Fase 4: Gemelo Digital',
      icon: Cpu,
      tag: 'SEIR + ABM',
      description: 'Calibración de arquitectura híbrida (Metapoblación SEIR + Agentes intra-hogar)',
    },
    {
      id: 'evaluation_validation',
      label: 'Fase 5 (CRISP-DM) - Evaluación y Validación',
      shortLabel: 'Fase 5: Validación',
      icon: CheckCircle2,
      tag: 'MAPE / KS',
      description: 'Métricas de prueba 2020-2022 vs 2023-2024, MAPE, RMSE, R², KS y Anderson-Darling',
    },
    {
      id: 'scenario_deployment',
      label: 'Fase 6 (CRISP-DM) - Despliegue de Escenarios (Toma de Decisiones)',
      shortLabel: 'Fase 6: Despliegue NPIs',
      icon: Sliders,
      tag: 'NPIs / DALYs',
      description: 'Simulación de cierres, restricciones, vacunación, saturación UCI y DALYs evitados',
    },
    {
      id: 'model_monitoring',
      label: 'Fase 6 (CRISP-DM) - Monitoreo de Modelos (On-Demand)',
      shortLabel: 'Fase 6: Monitoreo Modelo',
      icon: Activity,
      tag: 'PSI / KS Drift',
      description: 'Supervisión de estabilidad poblacional (PSI), Kolmogorov-Smirnov y salud del modelo activo',
    },
    {
      id: 'weekly_forecasting',
      label: 'Predicción Semanal & Sensibilidad',
      shortLabel: 'Predicción Semanal',
      icon: TrendingUp,
      tag: 'Persistencia / RF',
      description: 'Vigilancia semanal de casos con modelo persistente (campeón) y exploración hipotética de sensibilidad',
    },
    {
      id: 'reporting',
      label: 'Generación de Informes (Reporting)',
      shortLabel: 'Informes (ReportLab/OpenPyXL)',
      icon: FileText,
      tag: 'PDF & Excel',
      description: 'Módulo transversal consolidado para exportación a PDF (ReportLab) y Excel (OpenPyXL)',
    },
  ].filter((m) => canAccessModule(role, m.id as any));

  // Herramientas de Soporte & Análisis Complementario
  const auxiliaryTools = [
    { id: 'langchain_agent', label: 'Agente Integrador LangChain', icon: Sparkles },
    { id: 'data_assistant', label: 'Asistente de datos del gemelo digital', icon: Bot },
    { id: 'dashboard', label: 'Dashboard General (Overview)', icon: Activity },
    { id: 'comparator', label: 'Análisis Comparativo (Trade-offs)', icon: Columns },
    { id: '3d_view', label: 'Visualización Espacial 3D & GIS', icon: Box },
    { id: 'api_docs', label: 'Documentación API (OpenAPI)', icon: Code2 },
  ].filter((m) => canAccessModule(role, m.id as any));

  return (
    <aside
      id="app_sidebar_left"
      className={`fixed top-0 left-0 bottom-0 z-50 flex flex-col justify-between transition-all duration-300 ease-in-out border-r ${
        darkMode ? 'bg-slate-950/95 border-slate-800/80 text-slate-200' : 'bg-white/95 border-slate-200 text-slate-800'
      } backdrop-blur-md shadow-2xl ${isCollapsed ? 'w-[72px]' : 'w-[280px]'}`}
    >
      {/* Sección Superior: Branding & Botón Toggle Colapsar/Expandir */}
      <div className="p-4 flex items-center justify-between border-b border-slate-800/60">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-blue-500/25 shrink-0">
            <Activity size={20} />
          </div>
          {!isCollapsed && (
            <div className="truncate">
              <h1 className="text-xs font-extrabold tracking-tight flex items-center gap-1.5 truncate">
                Digital Twin
                <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  CRISP-DM
                </span>
              </h1>
              <p className="text-[10px] text-slate-400 truncate">Kenia 47 Condados</p>
            </div>
          )}
        </div>

        {/* Botón de Hamburguesa para Colapsar / Expandir Sidebar */}
        <button
          id="btn_toggle_sidebar"
          onClick={onToggleCollapse}
          className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800 transition shrink-0 cursor-pointer"
          title={isCollapsed ? 'Expandir Sidebar' : 'Colapsar Sidebar'}
        >
          {isCollapsed ? <Menu size={18} /> : <X size={18} />}
        </button>
      </div>

      {/* Centro: Navegación de Módulos Base CRISP-DM */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6 scrollbar-none">
        {/* Grupo 1: Módulos Base Metodología CRISP-DM */}
        <div>
          {!isCollapsed && (
            <div className="px-2 mb-2.5">
              <span className="text-[10px] font-mono uppercase tracking-wider text-blue-400 block font-bold">
                Módulos Base (CRISP-DM)
              </span>
              <span className="text-[9px] text-slate-400 block">
                Arquitectura de Gestión Empresarial
              </span>
            </div>
          )}
          <nav className="space-y-1.5">
            {crispDmModules.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  id={`sidebar_item_${item.id}`}
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  title={isCollapsed ? item.label : item.description}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/25'
                      : darkMode
                      ? 'text-slate-300 hover:text-white hover:bg-slate-900/90 border border-transparent hover:border-slate-800'
                      : 'text-slate-700 hover:text-slate-950 hover:bg-slate-100 border border-transparent'
                  }`}
                >
                  <Icon size={18} className="shrink-0" />
                  {!isCollapsed && (
                    <div className="flex-1 text-left truncate flex items-center justify-between gap-1">
                      <span className="truncate text-[11px] leading-tight font-medium">
                        {item.shortLabel || item.label}
                      </span>
                      {item.tag && (
                        <span className={`text-[8px] font-mono shrink-0 px-1.5 py-0.5 rounded ${
                          isActive ? 'bg-white/20 text-white' : 'bg-slate-800/80 text-slate-400 border border-slate-700/50'
                        }`}>
                          {item.tag}
                        </span>
                      )}
                    </div>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Grupo 2: Herramientas de Soporte & Análisis */}
        <div>
          {!isCollapsed && (
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block px-2 mb-2 font-bold">
              Herramientas de Soporte
            </span>
          )}
          <nav className="space-y-1">
            {auxiliaryTools.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  id={`sidebar_item_${item.id}`}
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  title={isCollapsed ? item.label : undefined}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                    isActive
                      ? 'bg-blue-600/20 border border-blue-500/40 text-blue-400 font-semibold'
                      : darkMode
                      ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon size={16} className="shrink-0" />
                  {!isCollapsed && <span className="truncate text-[11px]">{item.label}</span>}
                </button>
              );
            })}
          </nav>
        </div>

      </div>

      {/* Sección Inferior: Selector de Tema & Metadatos */}
      <div className="p-3 border-t border-slate-800/60 space-y-2">
        {/* Toggle de Tema Claro / Oscuro */}
        <button
          id="btn_sidebar_theme_toggle"
          onClick={onToggleTheme}
          className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
            darkMode ? 'bg-slate-900 text-slate-200 hover:bg-slate-800' : 'bg-slate-100 text-slate-800 hover:bg-slate-200'
          }`}
          title="Alternar Modo Claro / Oscuro"
        >
          <div className="flex items-center gap-2">
            {darkMode ? <Sun size={15} className="text-amber-400" /> : <Moon size={15} className="text-indigo-600" />}
            {!isCollapsed && <span>{darkMode ? 'Modo Claro' : 'Modo Oscuro'}</span>}
          </div>
          {!isCollapsed && (
            <span className="text-[10px] font-mono text-slate-400">
              {darkMode ? 'Dark' : 'Light'}
            </span>
          )}
        </button>

        {!isCollapsed && (
          <div className="text-[9px] text-slate-400 text-center font-mono pt-1">
            CRISP-DM Standard • FastAPI + React
          </div>
        )}
      </div>
    </aside>
  );
};
