import React, { useState } from 'react';
import { Activity, Shield, Lock, Eye, EyeOff, LogIn, User as UserIcon, KeyRound } from 'lucide-react';
import { ApiClient } from '../services/apiClient';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'epidemiologist' | 'analyst';
}

interface LoginProps {
  onLogin: (token: string, user: AuthUser) => void;
  darkMode: boolean;
}

const DEMO_ACCOUNTS = [
  { role: 'admin', email: 'admin@epidemic-twin.ke', password: 'AdminSecure2026!', label: 'Administrador (Admin)' },
  { role: 'epidemiologist', email: 'dr.wanjiku@health.go.ke', password: 'EpiChief2026!', label: 'Epidemióloga Jefe (Dra. Wanjiku)' },
  { role: 'analyst', email: 'omondi@moh.go.ke', password: 'AnalystMOH2026!', label: 'Analista MOH (Omondi)' },
];

export const Login: React.FC<LoginProps> = ({ onLogin, darkMode }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const data = await ApiClient.login(email, password);
      const user: AuthUser = {
        id: data.user_id,
        name: data.name,
        email: data.email,
        role: data.role as any,
      };
      onLogin(data.access_token, user);
    } catch (err: any) {
      setError(err.message || 'Error de autenticación. Verifique sus credenciales.');
      setLoading(false);
    }
  };

  const fillDemo = (acc: typeof DEMO_ACCOUNTS[number]) => {
    setEmail(acc.email);
    setPassword(acc.password);
    setError('');
  };

  return (
    <div className={`min-h-screen flex items-center justify-center p-4 transition-colors ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      <div className={`w-full max-w-md rounded-3xl border shadow-2xl overflow-hidden ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        {/* Header */}
        <div className="p-7 pb-5 text-center bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center text-white shadow-lg mb-3">
            <Activity size={26} />
          </div>
          <h1 className="text-lg font-extrabold text-white tracking-tight">Population Digital Twin</h1>
          <p className="text-[11px] text-blue-100 mt-0.5">Pandemic Preparedness · Kenya 47 Counties (FastAPI Backend)</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-7 space-y-4">
          <div>
            <label className={`text-xs font-semibold block mb-1.5 ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>Email</label>
            <div className="relative">
              <UserIcon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="usuario@epidemic-twin.ke"
                className={`w-full rounded-xl pl-9 pr-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none border ${darkMode ? 'bg-slate-950 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'}`}
              />
            </div>
          </div>

          <div>
            <label className={`text-xs font-semibold block mb-1.5 ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>Contraseña</label>
            <div className="relative">
              <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className={`w-full rounded-xl pl-9 pr-10 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none border ${darkMode ? 'bg-slate-950 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-800'}`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-500 cursor-pointer"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {error && (
            <div className="p-2.5 rounded-xl text-xs bg-red-500/10 border border-red-500/30 text-red-400 font-medium">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-sm font-bold shadow-lg shadow-blue-500/25 transition disabled:opacity-50 cursor-pointer"
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <LogIn size={16} />
            )}
            Iniciar Sesión
          </button>

          {/* Demo Accounts */}
          <div className={`pt-3 border-t ${darkMode ? 'border-slate-800' : 'border-slate-200'}`}>
            <div className="flex items-center gap-1.5 mb-2">
              <KeyRound size={14} className="text-blue-400" />
              <span className={`text-[10px] font-mono uppercase tracking-wider font-bold ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Cuentas de demostración oficiales (clic para autocompletar)
              </span>
            </div>
            <div className="grid grid-cols-1 gap-2">
              {DEMO_ACCOUNTS.map((acc) => (
                <button
                  key={acc.role}
                  type="button"
                  onClick={() => fillDemo(acc)}
                  className={`flex items-center justify-between px-3 py-2 rounded-xl border text-[11px] font-medium text-left transition cursor-pointer ${darkMode ? 'bg-slate-950 border-slate-700 hover:border-blue-500 text-slate-300' : 'bg-slate-50 border-slate-200 hover:border-blue-400 text-slate-700'}`}
                >
                  <div className="flex items-center gap-2">
                    <Shield size={13} className="text-blue-400 shrink-0" />
                    <span className="font-semibold">{acc.label}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{acc.email}</span>
                </button>
              ))}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
